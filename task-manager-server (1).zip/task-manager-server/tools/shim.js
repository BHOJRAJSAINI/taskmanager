(function () {
  // Drop-in replacement for Google Apps Script's google.script.run -> POST /api/rpc
  function call(name, args, ok, fail) {
    fetch('/api/rpc', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fn: name, args: args })
    })
      .then(function (r) {
        return r.text().then(function (t) {
          var j; try { j = JSON.parse(t); } catch (e) { j = { ok: false, error: 'HTTP ' + r.status + (t ? ': ' + t.slice(0, 200) : '') }; }
          return j;
        });
      })
      .then(function (j) {
        if (j && j.ok) { if (ok) ok(j.result); }
        else if (fail) fail({ message: (j && j.error) || 'Request failed' });
        else console.error('[rpc] ' + name + ' failed:', j && j.error);
      })
      .catch(function (e) { if (fail) fail(e); else console.error('[rpc] ' + name + ' failed:', e); });
  }
  function make(ok, fail) {
    return new Proxy({}, {
      get: function (_, name) {
        if (name === 'withSuccessHandler') return function (f) { return make(f, fail); };
        if (name === 'withFailureHandler') return function (f) { return make(ok, f); };
        if (name === 'withUserObject') return function () { return make(ok, fail); };
        if (typeof name !== 'string' || name === 'then') return undefined;
        return function () { call(name, Array.prototype.slice.call(arguments), ok, fail); };
      }
    });
  }
  window.google = { script: { run: make(null, null) } };
})();
