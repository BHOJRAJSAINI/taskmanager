'use strict';
/**
 * Generates lib/code.js (server logic) and public/index.html (frontend) from the untouched
 * originals in /original. Re-run after changing original/Code.gs or original/Index.html.
 *   node tools/port.js
 */
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
let code = fs.readFileSync(path.join(root, 'original/Code.gs'), 'utf8').replace(/\r\n/g, '\n');
let html = fs.readFileSync(path.join(root, 'original/Index.html'), 'utf8').replace(/\r\n/g, '\n');

function replaceBetween(src, startMarker, endMarker, replacement, label) {
  const a = src.indexOf(startMarker);
  const b = src.indexOf(endMarker, a + 1);
  if (a < 0 || b < 0) throw new Error('port: markers not found for ' + label);
  return src.slice(0, a) + replacement + src.slice(b);
}
function replaceOnce(src, from, to, label) {
  const i = src.indexOf(from);
  if (i < 0) throw new Error('port: pattern not found for ' + label);
  if (src.indexOf(from, i + 1) >= 0) throw new Error('port: pattern not unique for ' + label);
  return src.slice(0, i) + to + src.slice(i + from.length);
}

// ---------------------------------------------------------------- Code.gs
// 1. HtmlService entry points are not needed (static hosting)
code = replaceBetween(code, 'function doGet(e) {', '// ====================== ROLE HELPERS',
  '// (doGet/include removed: the frontend is served statically)\n\n', 'doGet');

// 2. Sessions: stateless signed tokens instead of CacheService
code = replaceOnce(code,
`    const token = Utilities.getUuid();
    CacheService.getScriptCache().put(
      CONFIG.SESSION_CACHE_PREFIX + token,
      JSON.stringify(matchedUser),
      CONFIG.SESSION_TTL_SECONDS
    );
`,
`    const token = __auth.signToken(matchedUser, CONFIG.SESSION_TTL_SECONDS);
`, 'login token');
code = replaceOnce(code,
`    const cache = CacheService.getScriptCache();
    const cached = cache.get(CONFIG.SESSION_CACHE_PREFIX + token);
    if (!cached) return { success: false, message: 'Session expired' };
    const user = JSON.parse(cached);
    cache.put(CONFIG.SESSION_CACHE_PREFIX + token, cached, CONFIG.SESSION_TTL_SECONDS);
    return { success: true, data: user };`,
`    const user = __auth.verifyToken(token);
    if (!user) return { success: false, message: 'Session expired' };
    return { success: true, data: user };`, 'validateSession');
code = replaceOnce(code,
`    if (token) CacheService.getScriptCache().remove(CONFIG.SESSION_CACHE_PREFIX + token);
`, `    // stateless tokens: the client simply discards its token\n`, 'logout');

// 3. Drive photo upload -> external op
code = replaceOnce(code,
`      const folder = DriveApp.getFolderById(CONFIG.CHECKLIST_PHOTO_FOLDER_ID);
      const bytes = Utilities.base64Decode(formData.photoData);
      const mime = formData.photoMimeType || 'image/jpeg';
      const rawName = String(formData.photoName || 'photo.jpg');
      const ext = rawName.indexOf('.') !== -1 ? rawName.split('.').pop() : 'jpg';
      const fileName = targetId + '_' + new Date().getTime() + '.' + ext;
      const blob = Utilities.newBlob(bytes, mime, fileName);
      const file = folder.createFile(blob);
      try { file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) {}
      photoUrl = file.getUrl();`,
`      const mime = formData.photoMimeType || 'image/jpeg';
      const rawName = String(formData.photoName || 'photo.jpg');
      const ext = rawName.indexOf('.') !== -1 ? rawName.split('.').pop() : 'jpg';
      const fileName = targetId + '_' + new Date().getTime() + '.' + ext;
      if (!formData.photoData) throw new Error('Photo data missing');
      photoUrl = __external('uploadPhoto', {
        folderId: CONFIG.CHECKLIST_PHOTO_FOLDER_ID,
        base64: String(formData.photoData),
        mime: mime,
        fileName: fileName
      });`, 'photo upload');

// 4. FMS submodule spreadsheet creation -> external op
code = replaceBetween(code, 'function fmsCreateSubmoduleSpreadsheet_(submoduleName) {', 'function fmsOpenSubmoduleSheet_',
`function fmsCreateSubmoduleSpreadsheet_(submoduleName) {
  return __external('createSubmoduleSpreadsheet', {
    name: submoduleName,
    sheets: [
      { title: FMS_CONFIG.TASK_SHEET, headers: FMS_CONFIG.TASK_HEADERS },
      { title: FMS_CONFIG.STEP_SHEET, headers: FMS_CONFIG.STEP_HEADERS },
      { title: FMS_CONFIG.ASSIGNMENT_SHEET, headers: FMS_CONFIG.ASSIGN_HEADERS }
    ]
  });
}

`, 'fms create');

// 5. Never swallow the "need data / external op" control-flow exceptions
let catchCount = 0;
code = code.replace(/catch\s*\((\w+)\)\s*\{/g, (m, v) => { catchCount++; return 'catch (' + v + ') { if (' + v + ' && ' + v + '.__need) throw ' + v + ';'; });
if (catchCount < 50) throw new Error('port: unexpectedly few catch blocks: ' + catchCount);
if (/catch\s*\{/.test(code)) throw new Error('port: found a catch without binding');

// 6. Public RPC whitelist = functions that take a session token (+ login + id helper)
const names = new Set(['loginUser', 'getNextDelegationTaskId']);
const re = /^function (\w+)\(([^)]*)\)\s*\{/gm;
let m;
while ((m = re.exec(code))) {
  const [, name, params] = m;
  if (/\btoken\b/.test(params) && name !== 'validateSession') names.add(name);
}
const exported = [...names].sort();
const body =
`// AUTO-GENERATED by tools/port.js from original/Code.gs — do not edit by hand.
module.exports = function (G) {
  const { SpreadsheetApp, LockService, Utilities, Logger, __external, __auth } = G;
${code}

  return { CONFIG, HELP_TICKET_CONFIG, FMS_CONFIG,
${exported.map((n) => '    ' + n).join(',\n')}
  };
};
`;
// leftover GAS globals audit
const left = body.match(/\b(CacheService|DriveApp|HtmlService|PropertiesService|UrlFetchApp|MailApp|GmailApp|ScriptApp|Session)\./g);
if (left) throw new Error('port: leftover GAS globals: ' + [...new Set(left)].join(', '));
if (/SpreadsheetApp\.create\(/.test(body)) throw new Error('port: SpreadsheetApp.create remains');
fs.writeFileSync(path.join(root, 'lib/code.js'), body);

// ---------------------------------------------------------------- Index.html
const shim = fs.readFileSync(path.join(__dirname, 'shim.js'), 'utf8');
html = replaceOnce(html, '<base target="_top">', '<script>\n' + shim + '</script>', 'base tag');
if (/<\?[=!]?/.test(html)) throw new Error('port: apps-script scriptlets remain in Index.html');

html = replaceOnce(html, 'function readFileAsBase64(file){',
`// Vercel limits request bodies to ~4.5 MB, so photos are downscaled in the browser first.
async function compressImageForUpload(file){
  const fallback = async () => ({ base64: await readFileAsBase64(file), mime: file.type || 'image/jpeg', name: file.name });
  try {
    if (!/^image\\//.test(file.type || '')) return await fallback();
    const url = URL.createObjectURL(file);
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
    const MAX = 1600;
    const scale = Math.min(1, MAX / Math.max(img.naturalWidth, img.naturalHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
    canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
    URL.revokeObjectURL(url);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
    const base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
    if (base64.length > 3.2 * 1024 * 1024) throw new Error('Photo is still too large after compression');
    const base = String(file.name || 'photo').replace(/\\.[^.]+$/, '');
    return { base64, mime: 'image/jpeg', name: base + '.jpg' };
  } catch (e) {
    if (file.size > 3 * 1024 * 1024) throw e;
    return await fallback();
  }
}

function readFileAsBase64(file){`, 'compress fn');
html = replaceOnce(html, 'const base64 = await readFileAsBase64(file);', 'const photo = await compressImageForUpload(file);\n    const base64 = photo.base64;', 'photo read');
html = replaceOnce(html, 'photoName: file.name,', 'photoName: photo.name,', 'photo name');
html = replaceOnce(html, "photoMimeType: file.type || 'image/jpeg',", 'photoMimeType: photo.mime,', 'photo mime');
fs.writeFileSync(path.join(root, 'public/index.html'), html);

console.log('port ok — catch blocks patched: ' + catchCount + ', exported RPC functions: ' + exported.length);
