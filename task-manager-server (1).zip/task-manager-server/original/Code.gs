/**
 * ============================================================
 *  TASK MANAGER — Google Apps Script Backend (v3.14.0)
 *
 *  v3.14.0 — FMS LAZY STEP GENERATION & FULL DYNAMIC WORKFLOW
 *
 *   - REQUIREMENT 1: Step-wise Completion Forms (per-step config)
 *   - REQUIREMENT 2: Dropdown option builder with label/value pairs
 *   - REQUIREMENT 3: Custom Logic — Skip Intermediate Steps
 *                    and Generate Target Step (with audit trail)
 *   - REQUIREMENT 4: Role-based FMS toolbar enforcement
 *   - REQUIREMENT 5: All Add Record Form fields available for prefill
 *   - REQUIREMENT 6: Dropdown persistence + validation
 *   - REQUIREMENT 7: ONLY Step 1 generated on record creation.
 *                    Subsequent steps generated lazily via Custom Logic.
 *
 *  PRESERVED FROM v3.13.0:
 *   - FMS module architecture, submodule spreadsheets, all APIs.
 *   - Complete Flow Management System (FMS).
 *   - Help Ticket integrated into Dashboard V2.
 *   - All existing modules and functionality.
 * ============================================================
 */

const CONFIG = {
  MASTER_CHECKLIST_SPREADSHEET_ID: '17-XljgEdKtk_Mux8Z0z949XWkVFGHW2u7hEXM2ub0bE',
  MASTER_CHECKLIST_SHEET: 'Master Checklist',
  MASTER_CHECKLIST_COLUMNS: 10,
  MASTER_CHECKLIST_EA_COLUMNS: 12,

  TASK_LIST_SPREADSHEET_ID: '1N8kV9QNMELh78ER3Hc-gkOK9bCdYtaFXe_GjsX6MW-g',
  TASK_LIST_SHEET: 'Task List',
  TASK_LIST_START_COL: 1,
  TASK_LIST_COLUMNS: 10,

  DOER_LIST_SPREADSHEET_ID: '1N8kV9QNMELh78ER3Hc-gkOK9bCdYtaFXe_GjsX6MW-g',
  DOER_LIST_SHEET: 'Doer List',
  DOER_LIST_START_COL: 1,
  DOER_LIST_COLUMNS: 4,
  DOER_LIST_STATUS_COL: 5,

  DELEGATION_SPREADSHEET_ID: '1W-vmPUY09k7a2U-g2EQHVnlMCfWkt0ZTE7mtaJ34FYg',
  DELEGATION_SHEET: 'Delegation Task',
  DELEGATION_START_ROW: 2,
  DELEGATION_COLUMNS: 14,
  DELEGATION_EA_STATUS_COLUMNS: 16,

  USER_SPREADSHEET_ID: '1RYzLVoWsjj7Brm-wkFIFRSbim0RL6pm-ZcMJD3Y5mQU',
  USER_SHEET: 'User sheet',

  CHECKLIST_PHOTO_FOLDER_ID: '16TiLYcxdjBCUHcFKARa1J9x9HXWiqze1',

  VALID_FREQUENCIES: ['D', 'W', 'M', 'Q', 'HY', 'Y', 'BW', 'BM'],
  VALID_HOLIDAY_PRIORITY: ['After', 'Before'],
  VALID_DELEGATION_ASSIGNERS: ['MD', 'EXECUTIVE ASSISSTANT'],

  ADMIN_EMAILS: ['dasha@global-india.com'],

  SESSION_CACHE_PREFIX: 'session_',
  SESSION_TTL_SECONDS: 86400
};

// Normalized role constants (used for all comparisons)
const ROLE_ADMIN = 'admin';
const ROLE_EA = 'executive assisstant';   // NOTE: misspelling preserved to match sheet
const ROLE_DOER = 'doer';

// ====================== ENTRY POINT ======================

function doGet(e) {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('Task Manager')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

// ====================== ROLE HELPERS ======================

function deriveUserRoleFromName(name) {
  const n = (name || '').toString().trim().toLowerCase();
  if (n === 'admin' || n === 'super_admin' || n === 'superadmin') return 'Admin';
  if (n === ROLE_EA) return 'EXECUTIVE ASSISSTANT';
  return 'Doer';
}

function isAdminRole_(role) {
  return (role || '').toString().trim().toLowerCase() === ROLE_ADMIN;
}

function isEARole_(role) {
  return (role || '').toString().trim().toLowerCase() === ROLE_EA;
}

function isAdminOrEA_(role) {
  return isAdminRole_(role) || isEARole_(role);
}

// ====================== AUTHENTICATION ======================

function loginUser(username, password) {
  try {
    if (!username || !password) {
      return { success: false, message: 'Username and password are required' };
    }

    const sheet = openSheet(CONFIG.DOER_LIST_SPREADSHEET_ID, CONFIG.DOER_LIST_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return { success: false, message: 'No users configured' };

    ensureUserStatusColumn_(sheet);
    const width = Math.max(CONFIG.DOER_LIST_COLUMNS, CONFIG.DOER_LIST_STATUS_COL);

    const values = sheet.getRange(2, 1, lastRow - 1, width).getValues();
    const inputUser = username.toString().trim().toLowerCase();
    const inputPass = password.toString();

    let matchedUser = null;
    for (let i = 0; i < values.length; i++) {
      const userName = (values[i][0] || '').toString().trim();
      const userPass = (values[i][3] || '').toString();
      const userStatus = (values[i][4] || '').toString().trim().toLowerCase();

      if (userStatus === 'inactive') continue;

      if (userName.toLowerCase() === inputUser && userPass === inputPass) {
        const userRole = deriveUserRoleFromName(userName);
        matchedUser = { userName: userName, userRole: userRole, row: i + 2 };
        break;
      }
    }

    if (!matchedUser) return { success: false, message: 'Invalid username or password' };

    const token = Utilities.getUuid();
    CacheService.getScriptCache().put(
      CONFIG.SESSION_CACHE_PREFIX + token,
      JSON.stringify(matchedUser),
      CONFIG.SESSION_TTL_SECONDS
    );

    return {
      success: true,
      message: 'Login successful',
      data: { token: token, userName: matchedUser.userName, userRole: matchedUser.userRole }
    };
  } catch (err) {
    return handleError(err, 'loginUser');
  }
}

function validateSession(token) {
  try {
    if (!token) return { success: false, message: 'No token provided' };
    const cache = CacheService.getScriptCache();
    const cached = cache.get(CONFIG.SESSION_CACHE_PREFIX + token);
    if (!cached) return { success: false, message: 'Session expired' };
    const user = JSON.parse(cached);
    cache.put(CONFIG.SESSION_CACHE_PREFIX + token, cached, CONFIG.SESSION_TTL_SECONDS);
    return { success: true, data: user };
  } catch (err) {
    return handleError(err, 'validateSession');
  }
}

function logoutUser(token) {
  try {
    if (token) CacheService.getScriptCache().remove(CONFIG.SESSION_CACHE_PREFIX + token);
    return { success: true, message: 'Logged out' };
  } catch (err) {
    return handleError(err, 'logoutUser');
  }
}

function getCurrentUser(token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };
    return {
      success: true,
      data: {
        userName: session.data.userName,
        userRole: session.data.userRole,
        isAdmin: isAdminRole_(session.data.userRole)
      }
    };
  } catch (err) {
    return handleError(err, 'getCurrentUser');
  }
}

// ====================== MASTER CHECKLIST ======================

function getMasterTasks(token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const sheet = openSheet(CONFIG.MASTER_CHECKLIST_SPREADSHEET_ID, CONFIG.MASTER_CHECKLIST_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return successResponse([]);

    const values = sheet.getRange(2, 1, lastRow - 1, CONFIG.MASTER_CHECKLIST_EA_COLUMNS).getValues();
    const now = new Date();

    let tasks = values.map((row, idx) => formatTaskData(row, idx, now)).filter(t => t.taskId !== '');

    const currentUser = (session.data.userName || '').toString().trim();
    const role = session.data.userRole;

    if (!isAdminOrEA_(role)) {
      tasks = tasks.filter(t => t.responsiblePerson.toLowerCase() === currentUser.toLowerCase());
    }

    return successResponse(tasks, 'Master tasks loaded');
  } catch (err) {
    return handleError(err, 'getMasterTasks');
  }
}

function getChecklistTasks(token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const sheet = openSheet(CONFIG.MASTER_CHECKLIST_SPREADSHEET_ID, CONFIG.MASTER_CHECKLIST_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return successResponse([]);

    const values = sheet.getRange(2, 1, lastRow - 1, CONFIG.MASTER_CHECKLIST_EA_COLUMNS).getValues();
    const now = new Date();

    let tasks = values.map((row, idx) => formatTaskData(row, idx, now)).filter(t => t.taskId !== '');

    const currentUser = (session.data.userName || '').toString().trim();
    const role = session.data.userRole;

    if (isAdminOrEA_(role)) {
      // Admin / EA → all tasks
    } else {
      tasks = tasks.filter(t => {
        if (t.responsiblePerson.toLowerCase() !== currentUser.toLowerCase()) return false;
        if (!t.isCompleted) return true;
        if (t.isNotVerified) return true;
        return false;
      });
    }

    return successResponse(tasks, 'Checklist tasks loaded');
  } catch (err) {
    return handleError(err, 'getChecklistTasks');
  }
}

function formatTaskData(row, rowIndex, now) {
  const taskId = row[0];
  const responsiblePerson = row[1];
  const task = row[2];
  const timeVal = row[3];
  const dateVal = row[4];
  const planned = row[5];
  const freq = row[6];
  const timestamp = row[7];
  const photoLink = row[8];
  const remarks = row[9];
  const verificationTs = row[10];
  const verificationStatus = row[11];

  let plannedDateTime = parseCompletionDateTime(planned);
  if (!plannedDateTime) plannedDateTime = combineDateAndTime(dateVal, timeVal);

  const isCompleted = !(timestamp === '' || timestamp === null || timestamp === undefined);
  let status = calculateTaskStatus(isCompleted, plannedDateTime, now);

  const completionDateTime = isCompleted ? parseCompletionDateTime(timestamp) : null;
  const verificationDateTime = parseCompletionDateTime(verificationTs);

  const verificationStatusStr = verificationStatus ? String(verificationStatus).trim() : '';
  const verificationStatusLower = verificationStatusStr.toLowerCase();
  const isNotVerified = (verificationStatusLower === 'not verified');
  const hasVerificationTs = !(verificationTs === '' || verificationTs === null || verificationTs === undefined);
  const isVerified = hasVerificationTs && !isNotVerified;

  if (isVerified) status = 'VERIFIED';

  let timeDisplay = '';
  if (timeVal instanceof Date) timeDisplay = formatTimeOnly(timeVal);
  else if (timeVal) timeDisplay = String(timeVal);

  let dateDisplay = '';
  if (dateVal instanceof Date) dateDisplay = formatDateOnly(dateVal);
  else if (dateVal) dateDisplay = String(dateVal);

  return {
    rowNumber: rowIndex + 2,
    taskId: (taskId === '' || taskId === null || taskId === undefined) ? '' : String(taskId),
    responsiblePerson: responsiblePerson ? String(responsiblePerson) : '',
    task: task ? String(task) : '',
    time: timeDisplay,
    dateDisplay: dateDisplay,
    plannedDateTime: plannedDateTime ? plannedDateTime.getTime() : null,
    plannedDateTimeDisplay: plannedDateTime ? formatDateTime(plannedDateTime) : '—',
    frequency: freq ? String(freq) : '',
    timestamp: timestamp ? String(timestamp) : '',
    timestampDisplay: completionDateTime ? formatDateTime(completionDateTime) : (timestamp ? String(timestamp) : ''),
    photoLink: photoLink ? String(photoLink).trim() : '',
    remarks: remarks ? String(remarks) : '',
    isCompleted: isCompleted,
    completion: timestamp ? String(timestamp) : '',
    completionDateTime: completionDateTime ? completionDateTime.getTime() : null,
    status: status,
    verificationTimestamp: verificationTs ? String(verificationTs) : '',
    verificationTimestampDisplay: verificationDateTime ? formatDateTime(verificationDateTime) : '',
    verificationStatus: verificationStatusStr,
    isVerified: isVerified,
    isNotVerified: isNotVerified
  };
}

function completeChecklistTask(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!formData || !formData.taskId || String(formData.taskId).trim() === '') {
      return { success: false, message: 'Task ID is required' };
    }
    if (!formData.photoData || !formData.photoName) {
      return { success: false, message: 'Photo is required' };
    }

    const sheet = openSheet(CONFIG.MASTER_CHECKLIST_SPREADSHEET_ID, CONFIG.MASTER_CHECKLIST_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return { success: false, message: 'No tasks found' };

    const idValues = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
    const targetId = String(formData.taskId).trim();
    let targetRow = -1;
    for (let i = 0; i < idValues.length; i++) {
      if (String(idValues[i][0]).trim() === targetId) { targetRow = i + 2; break; }
    }
    if (targetRow === -1) return { success: false, message: 'Task ID not found in Master Checklist' };

    const existingH = sheet.getRange(targetRow, 8).getValue();
    const existingL = sheet.getRange(targetRow, 12).getValue();
    const existingLStr = existingL ? String(existingL).trim().toLowerCase() : '';

    const isHBlank = (existingH === '' || existingH === null || existingH === undefined);
    const isNotVerified = (existingLStr === 'not verified');

    if (!isHBlank && !isNotVerified) {
      return { success: false, message: 'This task has already been completed and is locked' };
    }

    if (isNotVerified) {
      sheet.getRange(targetRow, 11).setValue('');
      sheet.getRange(targetRow, 12).setValue('');
    }

    let photoUrl = '';
    try {
      const folder = DriveApp.getFolderById(CONFIG.CHECKLIST_PHOTO_FOLDER_ID);
      const bytes = Utilities.base64Decode(formData.photoData);
      const mime = formData.photoMimeType || 'image/jpeg';
      const rawName = String(formData.photoName || 'photo.jpg');
      const ext = rawName.indexOf('.') !== -1 ? rawName.split('.').pop() : 'jpg';
      const fileName = targetId + '_' + new Date().getTime() + '.' + ext;
      const blob = Utilities.newBlob(bytes, mime, fileName);
      const file = folder.createFile(blob);
      try { file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) {}
      photoUrl = file.getUrl();
    } catch (uploadErr) {
      return { success: false, message: 'Unable to upload photo: ' + (uploadErr && uploadErr.message ? uploadErr.message : uploadErr) };
    }

    const timestamp = new Date();
    const remarks = formData.remarks ? String(formData.remarks) : '';
    sheet.getRange(targetRow, 8, 1, 3).setValues([[timestamp, photoUrl, remarks]]);

    return successResponse({ row: targetRow, photoUrl: photoUrl }, 'Task completed successfully');
  } catch (err) {
    return handleError(err, 'completeChecklistTask');
  }
}

function verifyChecklistTask(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!isAdminOrEA_(session.data.userRole)) {
      return { success: false, message: 'Only EA or Admin can verify tasks' };
    }

    if (!formData || !formData.taskId || String(formData.taskId).trim() === '') {
      return { success: false, message: 'Task ID is required' };
    }

    const sheet = openSheet(CONFIG.MASTER_CHECKLIST_SPREADSHEET_ID, CONFIG.MASTER_CHECKLIST_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return { success: false, message: 'No tasks found' };

    const idValues = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
    const targetId = String(formData.taskId).trim();
    let targetRow = -1;
    for (let i = 0; i < idValues.length; i++) {
      if (String(idValues[i][0]).trim() === targetId) { targetRow = i + 2; break; }
    }
    if (targetRow === -1) return { success: false, message: 'Task ID not found' };

    const completionTs = sheet.getRange(targetRow, 8).getValue();
    if (completionTs === '' || completionTs === null || completionTs === undefined) {
      return { success: false, message: 'Cannot verify — Doer has not completed this task yet' };
    }

    const timestamp = new Date();
    const verStatusRaw = formData.verificationStatus
      ? String(formData.verificationStatus).trim()
      : 'Verified';
    const verStatusLower = verStatusRaw.toLowerCase();
    const isNotVerified = (verStatusLower === 'not verified');

    sheet.getRange(targetRow, 11).setValue(timestamp);
    sheet.getRange(targetRow, 12).setValue(verStatusRaw);

    if (isNotVerified) {
      sheet.getRange(targetRow, 8, 1, 3).setValues([['', '', '']]);
    }

    return successResponse({
      row: targetRow,
      status: verStatusRaw,
      reopened: isNotVerified
    }, isNotVerified ? 'Task marked as Not Verified — reopened for Doer' : 'Task verified successfully');
  } catch (err) {
    return handleError(err, 'verifyChecklistTask');
  }
}

function parseCompletionDateTime(value) {
  if (!value) return null;
  if (value instanceof Date) return value;
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = new Date(value.trim());
    if (!isNaN(parsed.getTime())) return parsed;
  }
  return null;
}

function calculateTaskStatus(isCompleted, referenceDateTime, now) {
  if (isCompleted) return 'COMPLETED';
  if (referenceDateTime instanceof Date && !isNaN(referenceDateTime.getTime())) {
    if (referenceDateTime.getTime() < now.getTime()) return 'OVERDUE';
  }
  return 'PENDING';
}

function combineDateAndTime(dateVal, timeVal) {
  if (!dateVal) return null;
  let baseDate;
  if (dateVal instanceof Date) {
    baseDate = new Date(dateVal.getFullYear(), dateVal.getMonth(), dateVal.getDate());
  } else {
    const parsed = new Date(dateVal);
    if (isNaN(parsed.getTime())) return null;
    baseDate = new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
  }
  let hours = 0, minutes = 0, seconds = 0;
  if (timeVal instanceof Date) {
    hours = timeVal.getHours(); minutes = timeVal.getMinutes(); seconds = timeVal.getSeconds();
  } else if (typeof timeVal === 'string' && timeVal.trim() !== '') {
    const match = timeVal.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?/i);
    if (match) {
      hours = parseInt(match[1], 10);
      minutes = parseInt(match[2], 10);
      seconds = match[3] ? parseInt(match[3], 10) : 0;
      const ampm = match[4];
      if (ampm) {
        const upper = ampm.toUpperCase();
        if (upper === 'PM' && hours < 12) hours += 12;
        if (upper === 'AM' && hours === 12) hours = 0;
      }
    }
  }
  baseDate.setHours(hours, minutes, seconds, 0);
  return baseDate;
}

function formatDateTime(date) {
  const pad = n => String(n).padStart(2, '0');
  return `${pad(date.getDate())}-${pad(date.getMonth() + 1)}-${date.getFullYear()} ` +
         `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function formatDateOnly(date) {
  const pad = n => String(n).padStart(2, '0');
  return pad(date.getDate()) + '-' + pad(date.getMonth() + 1) + '-' + date.getFullYear();
}

function formatTimeOnly(date) {
  const pad = n => String(n).padStart(2, '0');
  let h = date.getHours();
  const m = pad(date.getMinutes());
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12 === 0 ? 12 : h % 12;
  return pad(h) + ':' + m + ' ' + ampm;
}

// ====================== DELEGATION MODULE ======================

function getDelegationTasks(token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const sheet = openSheet(CONFIG.DELEGATION_SPREADSHEET_ID, CONFIG.DELEGATION_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < CONFIG.DELEGATION_START_ROW) return successResponse([]);

    const numRows = lastRow - CONFIG.DELEGATION_START_ROW + 1;
    const values = sheet.getRange(CONFIG.DELEGATION_START_ROW, 1, numRows, CONFIG.DELEGATION_EA_STATUS_COLUMNS).getValues();

    const currentUser = (session.data.userName || '').toString().trim();
    const isAdmin = isAdminRole_(session.data.userRole);
    const isEA = isEARole_(session.data.userRole);

    let tasks = [];

    values.forEach((row, idx) => {
      const taskId = row[0];
      if (!taskId || String(taskId).trim() === '') return;

      const assignee = row[3] ? String(row[3]).trim() : '';
      const status = row[9];
      const verStatus = row[12];
      const verStatusLower = verStatus ? String(verStatus).trim().toLowerCase() : '';
      const isNotVerified = (verStatusLower === 'not verified');

      const isStatusBlank = (status === '' || status === null || status === undefined);

      let visible = false;
      if (isAdmin) {
        visible = true;
      } else if (isEA) {
        visible = true;
      } else {
        visible = (
          assignee.toLowerCase() === currentUser.toLowerCase() &&
          (isStatusBlank || isNotVerified)
        );
      }

      if (!visible) return;

      tasks.push(formatDelegationTask(row, idx));
    });

    return successResponse(tasks, 'Delegation tasks loaded');
  } catch (err) {
    return handleError(err, 'getDelegationTasks');
  }
}

function getAllDelegationTasksForStats(currentUser, roleLower) {
  try {
    const sheet = openSheet(CONFIG.DELEGATION_SPREADSHEET_ID, CONFIG.DELEGATION_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < CONFIG.DELEGATION_START_ROW) return [];

    const numRows = lastRow - CONFIG.DELEGATION_START_ROW + 1;
    const values = sheet.getRange(CONFIG.DELEGATION_START_ROW, 1, numRows, CONFIG.DELEGATION_EA_STATUS_COLUMNS).getValues();

    const now = new Date();
    const isAdmin = isAdminRole_(roleLower);
    const isEA = isEARole_(roleLower);
    const filterUser = (currentUser || '').toString().trim().toLowerCase();

    let tasks = [];

    values.forEach((row, idx) => {
      const taskId = row[0];
      if (!taskId || String(taskId).trim() === '') return;

      const assignee = row[3] ? String(row[3]).trim() : '';

      if (isEA && !isAdmin) {
        if (assignee.toLowerCase() !== ROLE_EA) return;
      }
      if (!isAdmin && !isEA) {
        if (assignee.toLowerCase() !== filterUser) return;
      }

      tasks.push(formatDelegationTaskForStats(row, idx, now));
    });

    return tasks;
  } catch (err) {
    console.error('[getAllDelegationTasksForStats] ' + (err && err.message ? err.message : err));
    return [];
  }
}

function formatDelegationTaskForStats(row, rowIndex, now) {
  const taskId = row[0];
  const assigner = row[2];
  const assignee = row[3];
  const task = row[4];
  const targetDate = row[6];
  const revisionCount = row[7];
  const completionTs = row[8];
  const statusRaw = row[9];
  const verificationTs = row[11];

  const parseDate = (v) => {
    if (!v) return null;
    if (v instanceof Date) return v;
    const d = new Date(v);
    return isNaN(d.getTime()) ? null : d;
  };

  const targetDateVal = parseDate(targetDate);
  const completionDate = parseDate(completionTs);
  const verificationDate = parseDate(verificationTs);

  const isStatusBlank = (statusRaw === '' || statusRaw === null || statusRaw === undefined);
  const isCompleted = !isStatusBlank;

  let status;
  if (isCompleted) {
    status = 'COMPLETED';
  } else if (targetDateVal && targetDateVal.getTime() < now.getTime()) {
    status = 'OVERDUE';
  } else {
    status = 'PENDING';
  }

  return {
    source: 'delegation',
    taskId: String(taskId),
    task: task ? String(task) : '',
    responsiblePerson: assignee ? String(assignee) : '',
    assigner: assigner ? String(assigner) : '',
    frequency: '',
    status: status,
    isCompleted: isCompleted,
    plannedDateTime: targetDateVal ? targetDateVal.getTime() : null,
    completionDateTime: completionDate ? completionDate.getTime() : null,
    verificationDateTime: verificationDate ? verificationDate.getTime() : null,
    isRevised: revisionCount ? (parseInt(revisionCount, 10) || 0) > 0 : false,
    revisionCount: revisionCount ? (parseInt(revisionCount, 10) || 0) : 0
  };
}

function formatDelegationTask(row, rowIndex) {
  const taskId = row[0];
  const timestamp = row[1];
  const assigner = row[2];
  const assignee = row[3];
  const task = row[4];
  const refTargetDate = row[5];
  const targetDate = row[6];
  const revisionCount = row[7];
  const completionTs = row[8];
  const status = row[9];
  const colK = row[10];
  const verificationTs = row[11];
  const verificationStatus = row[12];
  const revisedTargetDate = row[13];
  const eaCompletionTs = row[14];
  const eaStatusRaw = row[15];

  const parseDate = (v) => {
    if (!v) return null;
    if (v instanceof Date) return v;
    const d = new Date(v);
    return isNaN(d.getTime()) ? null : d;
  };

  const tsDate = parseDate(timestamp);
  const targetDateVal = parseDate(targetDate);
  const revisedTargetDateVal = parseDate(revisedTargetDate);
  const completionDate = parseDate(completionTs);
  const verificationDate = parseDate(verificationTs);

  const isStatusBlank = (status === '' || status === null || status === undefined);

  const verStatusStr = verificationStatus ? String(verificationStatus).trim() : '';
  const verStatusLower = verStatusStr.toLowerCase();
  const isNotVerified = (verStatusLower === 'not verified');
  const hasVerTs = !(verificationTs === '' || verificationTs === null || verificationTs === undefined);
  const isVerified = hasVerTs && !isNotVerified;

  return {
    rowNumber: rowIndex + CONFIG.DELEGATION_START_ROW,
    taskId: String(taskId),
    timestamp: tsDate ? tsDate.getTime() : null,
    timestampDisplay: tsDate ? formatDateTime(tsDate) : '—',
    assigner: assigner ? String(assigner) : '',
    assignee: assignee ? String(assignee) : '',
    task: task ? String(task) : '',
    targetDate: targetDateVal ? targetDateVal.getTime() : null,
    targetDateDisplay: targetDateVal ? formatDateOnly(targetDateVal) : '—',
    revisedTargetDate: revisedTargetDateVal ? revisedTargetDateVal.getTime() : null,
    revisedTargetDateDisplay: revisedTargetDateVal ? formatDateOnly(revisedTargetDateVal) : '',
    revisionCount: revisionCount ? parseInt(revisionCount, 10) || 0 : 0,
    completionTimestamp: completionDate ? completionDate.getTime() : null,
    completionTimestampDisplay: completionDate ? formatDateTime(completionDate) : '',
    status: isStatusBlank ? '' : String(status),
    isStatusBlank: isStatusBlank,
    verificationTimestamp: verificationDate ? verificationDate.getTime() : null,
    verificationTimestampDisplay: verificationDate ? formatDateTime(verificationDate) : '',
    verificationStatus: verStatusStr,
    isNotVerified: isNotVerified,
    isVerified: isVerified,
    isVerificationTsBlank: !hasVerTs,
    rawTask: task ? String(task) : '',
    rawAssignee: assignee ? String(assignee) : '',
    rawTargetDate: targetDateVal ? targetDateVal.getTime() : null,
    eaCompletionTimestamp: (function(){
      const d = parseDate(eaCompletionTs);
      return d ? d.getTime() : null;
    })(),
    eaCompletionTimestampDisplay: (function(){
      const d = parseDate(eaCompletionTs);
      return d ? formatDateTime(d) : '';
    })(),
    eaStatus: (eaStatusRaw === '' || eaStatusRaw === null || eaStatusRaw === undefined)
      ? ''
      : String(eaStatusRaw),
    isEaStatusDone: (function(){
      if (eaStatusRaw === '' || eaStatusRaw === null || eaStatusRaw === undefined) return false;
      return String(eaStatusRaw).trim().toLowerCase() === 'done';
    })()
  };
}

function getNextDelegationTaskId() {
  try {
    const sheet = openSheet(CONFIG.DELEGATION_SPREADSHEET_ID, CONFIG.DELEGATION_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < CONFIG.DELEGATION_START_ROW) return 'task-0001';

    const numRows = lastRow - CONFIG.DELEGATION_START_ROW + 1;
    const idValues = sheet.getRange(CONFIG.DELEGATION_START_ROW, 1, numRows, 1).getValues();

    let maxNum = 0;
    idValues.forEach(row => {
      const id = String(row[0] || '').trim();
      const match = id.match(/^task-(\d+)$/i);
      if (match) {
        const n = parseInt(match[1], 10);
        if (n > maxNum) maxNum = n;
      }
    });

    const nextNum = maxNum + 1;
    return 'task-' + String(nextNum).padStart(4, '0');
  } catch (err) {
    console.error('getNextDelegationTaskId error: ' + err);
    return 'task-0001';
  }
}

function createDelegationTask(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const role = session.data.userRole;
    if (!isAdminOrEA_(role) && (role || '').toString().trim().toLowerCase() !== 'md') {
      return { success: false, message: 'Only Admin, EA or MD can add delegation tasks' };
    }

    if (!formData) return { success: false, message: 'No form data received' };
    if (!formData.assigner || !CONFIG.VALID_DELEGATION_ASSIGNERS.includes(formData.assigner)) {
      return { success: false, message: 'Assigner must be MD or EA' };
    }
    if (!formData.assignee || String(formData.assignee).trim() === '') {
      return { success: false, message: 'Assignee is required' };
    }
    if (!formData.task || String(formData.task).trim() === '') {
      return { success: false, message: 'Task is required' };
    }
    if (!formData.targetDate || String(formData.targetDate).trim() === '') {
      return { success: false, message: 'Target Date is required' };
    }

    const sheet = openSheet(CONFIG.DELEGATION_SPREADSHEET_ID, CONFIG.DELEGATION_SHEET);
    const nextId = getNextDelegationTaskId();
    const now = new Date();

    const targetDateObj = new Date(formData.targetDate);
    if (isNaN(targetDateObj.getTime())) {
      return { success: false, message: 'Invalid Target Date' };
    }

    const targetRow = Math.max(sheet.getLastRow() + 1, CONFIG.DELEGATION_START_ROW);

    const rowValues = [
      nextId,
      now,
      sanitize(formData.assigner),
      sanitize(formData.assignee),
      sanitize(formData.task),
      targetDateObj,
      targetDateObj,
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      ''
    ];

    sheet.getRange(targetRow, 1, 1, CONFIG.DELEGATION_EA_STATUS_COLUMNS).setValues([rowValues]);

    return successResponse({ taskId: nextId, row: targetRow }, 'Delegation task created successfully');
  } catch (err) {
    return handleError(err, 'createDelegationTask');
  }
}

function completeDelegationTask(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!formData || !formData.taskId || String(formData.taskId).trim() === '') {
      return { success: false, message: 'Task ID is required' };
    }

    const sheet = openSheet(CONFIG.DELEGATION_SPREADSHEET_ID, CONFIG.DELEGATION_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < CONFIG.DELEGATION_START_ROW) return { success: false, message: 'No tasks found' };

    const numRows = lastRow - CONFIG.DELEGATION_START_ROW + 1;
    const idValues = sheet.getRange(CONFIG.DELEGATION_START_ROW, 1, numRows, 1).getValues();
    const targetId = String(formData.taskId).trim();
    let targetRow = -1;
    for (let i = 0; i < idValues.length; i++) {
      if (String(idValues[i][0]).trim() === targetId) { targetRow = i + CONFIG.DELEGATION_START_ROW; break; }
    }
    if (targetRow === -1) return { success: false, message: 'Task ID not found' };

    const rowValues = sheet.getRange(targetRow, 1, 1, CONFIG.DELEGATION_EA_STATUS_COLUMNS).getValues()[0];
    const assigneeStr = (rowValues[3] || '').toString().trim();
    const assigneeLower = assigneeStr.toLowerCase();
    const isEaRow = (assigneeLower === ROLE_EA);

    const doerStatusVal = rowValues[9];
    const eaStatusVal = rowValues[15];
    const verStatusVal = rowValues[12];
    const verStatusLower = verStatusVal ? String(verStatusVal).trim().toLowerCase() : '';
    const isNotVerified = (verStatusLower === 'not verified');

    const isDoerStatusBlank = (doerStatusVal === '' || doerStatusVal === null || doerStatusVal === undefined);
    const isEaStatusBlank = (eaStatusVal === '' || eaStatusVal === null || eaStatusVal === undefined);

    const timestamp = new Date();
    const status = formData.status ? String(formData.status).trim() : 'Completed';

    const isEaOrAdmin = isAdminOrEA_(session.data.userRole);

    if (isEaRow) {
      if (isDoerStatusBlank || isNotVerified) {
        if (isNotVerified) {
          sheet.getRange(targetRow, 12).setValue('');
          sheet.getRange(targetRow, 13).setValue('');
        }
        sheet.getRange(targetRow, 15).setValue('');
        sheet.getRange(targetRow, 16).setValue('');

        sheet.getRange(targetRow, 9).setValue(timestamp);
        sheet.getRange(targetRow, 10).setValue(status);

        return successResponse({
          row: targetRow,
          path: 'Doer',
          stage: 'doer'
        }, 'Doer completion recorded');
      }

      if (!isEaStatusBlank) {
        return { success: false, message: 'This task has already been completed by EA' };
      }

      if (isDoerStatusBlank) {
        return { success: false, message: 'Cannot complete — Doer has not completed this task yet' };
      }

      if (!isEaOrAdmin) {
        return { success: false, message: 'Only EA or Admin can complete the EA step' };
      }

      applyEaCompletionToRelatedRows_(sheet, targetRow, timestamp, 'Done');
      return successResponse({
        row: targetRow,
        path: 'EXECUTIVE ASSISSTANT',
        stage: 'EXECUTIVE ASSISSTANT'
      }, 'EA task completed successfully');
    }

    let useEaPath = false;

    if (isEaOrAdmin && !isDoerStatusBlank) {
      useEaPath = true;
    }

    if (useEaPath) {
      if (!isEaStatusBlank) {
        return { success: false, message: 'This task has already been completed by EA' };
      }
      if (isDoerStatusBlank) {
        return { success: false, message: 'Cannot complete — Doer has not completed this task yet' };
      }

      applyEaCompletionToRelatedRows_(sheet, targetRow, timestamp, 'Done');
      return successResponse({ row: targetRow, path: 'EXECUTIVE ASSISSTANT' }, 'EA task completed successfully');
    } else {
      if (isNotVerified) {
        sheet.getRange(targetRow, 12).setValue('');
        sheet.getRange(targetRow, 13).setValue('');
        sheet.getRange(targetRow, 9).setValue('');
        sheet.getRange(targetRow, 10).setValue('');
      } else if (!isDoerStatusBlank) {
        return { success: false, message: 'This task has already been completed' };
      }

      sheet.getRange(targetRow, 9).setValue(timestamp);
      sheet.getRange(targetRow, 10).setValue(status);

      return successResponse({ row: targetRow, path: 'Doer' }, 'Task completed successfully');
    }
  } catch (err) {
    return handleError(err, 'completeDelegationTask');
  }
}

function applyEaCompletionToRelatedRows_(sheet, eaRow, timestamp, eaStatus) {
  const lastRow = sheet.getLastRow();
  if (lastRow < CONFIG.DELEGATION_START_ROW) return;

  const numRows = lastRow - CONFIG.DELEGATION_START_ROW + 1;
  const allValues = sheet.getRange(
    CONFIG.DELEGATION_START_ROW, 1, numRows, CONFIG.DELEGATION_EA_STATUS_COLUMNS
  ).getValues();

  const eaRowValues = allValues[eaRow - CONFIG.DELEGATION_START_ROW];
  const eaAssigner = (eaRowValues[2] || '').toString().trim().toLowerCase();
  const eaTaskText = (eaRowValues[4] || '').toString().trim();
  const eaTargetRaw = eaRowValues[6];
  const eaTargetTime = (eaTargetRaw instanceof Date)
    ? eaTargetRaw.getTime()
    : (eaTargetRaw ? new Date(eaTargetRaw).getTime() : 0);

  for (let i = 0; i < allValues.length; i++) {
    const rowNumber = i + CONFIG.DELEGATION_START_ROW;
    const r = allValues[i];

    const rowTaskId = (r[0] || '').toString().trim();
    if (rowTaskId === '') continue;

    const rowAssigner = (r[2] || '').toString().trim().toLowerCase();
    const rowTaskText = (r[4] || '').toString().trim();
    const rowTargetRaw = r[6];
    const rowTargetTime = (rowTargetRaw instanceof Date)
      ? rowTargetRaw.getTime()
      : (rowTargetRaw ? new Date(rowTargetRaw).getTime() : 0);

    const isSameGroup =
      rowAssigner === eaAssigner &&
      rowTaskText === eaTaskText &&
      rowTargetTime === eaTargetTime;

    if (!isSameGroup) continue;

    sheet.getRange(rowNumber, 15).setValue(timestamp);
    sheet.getRange(rowNumber, 16).setValue(eaStatus);
  }
}

function verifyDelegationTask(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!formData || !formData.taskId || String(formData.taskId).trim() === '') {
      return { success: false, message: 'Task ID is required' };
    }

    const sheet = openSheet(CONFIG.DELEGATION_SPREADSHEET_ID, CONFIG.DELEGATION_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < CONFIG.DELEGATION_START_ROW) return { success: false, message: 'No tasks found' };

    const numRows = lastRow - CONFIG.DELEGATION_START_ROW + 1;
    const idValues = sheet.getRange(CONFIG.DELEGATION_START_ROW, 1, numRows, 1).getValues();
    const targetId = String(formData.taskId).trim();
    let targetRow = -1;
    for (let i = 0; i < idValues.length; i++) {
      if (String(idValues[i][0]).trim() === targetId) { targetRow = i + CONFIG.DELEGATION_START_ROW; break; }
    }
    if (targetRow === -1) return { success: false, message: 'Task ID not found' };

    const eaStatusVal = sheet.getRange(targetRow, 16).getValue();
    const eaStatusStr = (eaStatusVal === '' || eaStatusVal === null || eaStatusVal === undefined)
      ? '' : String(eaStatusVal).trim();
    if (eaStatusStr.toLowerCase() !== 'done') {
      return { success: false, message: 'Cannot verify — EA has not completed this task yet' };
    }

    const statusVal = sheet.getRange(targetRow, 10).getValue();
    if (statusVal === '' || statusVal === null || statusVal === undefined) {
      return { success: false, message: 'Cannot verify a task before it is completed' };
    }

    const timestamp = new Date();
    const verStatusRaw = formData.verificationStatus ? String(formData.verificationStatus).trim() : 'Verified';
    const verStatusLower = verStatusRaw.toLowerCase();
    const isNotVerified = (verStatusLower === 'not verified');

    sheet.getRange(targetRow, 12).setValue(timestamp);
    sheet.getRange(targetRow, 13).setValue(verStatusRaw);

    if (isNotVerified) {
      sheet.getRange(targetRow, 9).setValue('');
      sheet.getRange(targetRow, 10).setValue('');
    }

    return successResponse({
      row: targetRow,
      status: verStatusRaw,
      reopened: isNotVerified
    }, isNotVerified ? 'Task marked as Not Verified — reopened for Doer' : 'Task verified successfully');
  } catch (err) {
    return handleError(err, 'verifyDelegationTask');
  }
}

function reviseDelegationTask(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!isAdminOrEA_(session.data.userRole)) {
      return { success: false, message: 'Only Admin or EA can revise delegation tasks' };
    }

    if (!formData || !formData.taskId || String(formData.taskId).trim() === '') {
      return { success: false, message: 'Task ID is required' };
    }

    const sheet = openSheet(CONFIG.DELEGATION_SPREADSHEET_ID, CONFIG.DELEGATION_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < CONFIG.DELEGATION_START_ROW) return { success: false, message: 'No tasks found' };

    const numRows = lastRow - CONFIG.DELEGATION_START_ROW + 1;
    const idValues = sheet.getRange(CONFIG.DELEGATION_START_ROW, 1, numRows, 1).getValues();
    const targetId = String(formData.taskId).trim();
    let targetRow = -1;
    for (let i = 0; i < idValues.length; i++) {
      if (String(idValues[i][0]).trim() === targetId) { targetRow = i + CONFIG.DELEGATION_START_ROW; break; }
    }
    if (targetRow === -1) return { success: false, message: 'Task ID not found' };

    const currentRow = sheet.getRange(targetRow, 1, 1, CONFIG.DELEGATION_COLUMNS).getValues()[0];
    let revisionCount = currentRow[7];
    revisionCount = (revisionCount === '' || revisionCount === null || revisionCount === undefined)
      ? 0 : (parseInt(revisionCount, 10) || 0);

    let hasChange = false;

    if (formData.task !== undefined && formData.task !== null) {
      const newTask = String(formData.task).trim();
      const oldTask = currentRow[4] ? String(currentRow[4]).trim() : '';
      if (newTask !== '' && newTask !== oldTask) {
        sheet.getRange(targetRow, 5).setValue(sanitize(newTask));
        hasChange = true;
      }
    }

    if (formData.assignee !== undefined && formData.assignee !== null && String(formData.assignee).trim() !== '') {
      const newAssignee = String(formData.assignee).trim();
      const oldAssignee = currentRow[3] ? String(currentRow[3]).trim() : '';
      if (newAssignee !== oldAssignee) {
        sheet.getRange(targetRow, 4).setValue(sanitize(newAssignee));
        hasChange = true;
      }
    }

    if (formData.targetDate !== undefined && formData.targetDate !== null && String(formData.targetDate).trim() !== '') {
      const newTarget = new Date(formData.targetDate);
      if (!isNaN(newTarget.getTime())) {
        const oldTarget = currentRow[6];
        const oldTargetTime = oldTarget instanceof Date ? oldTarget.getTime() : (oldTarget ? new Date(oldTarget).getTime() : 0);
        if (newTarget.getTime() !== oldTargetTime) {
          sheet.getRange(targetRow, 7).setValue(newTarget);
          sheet.getRange(targetRow, 14).setValue(newTarget);
          hasChange = true;
        }
      }
    }

    if (hasChange) {
      revisionCount += 1;
      sheet.getRange(targetRow, 8).setValue(revisionCount);
    }

    return successResponse({ row: targetRow, revisionCount: revisionCount }, 'Task revised successfully');
  } catch (err) {
    return handleError(err, 'reviseDelegationTask');
  }
}

function changeDelegationAssignee(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!isAdminOrEA_(session.data.userRole)) {
      return { success: false, message: 'Only Admin or EA can change the assignee' };
    }

    if (!formData || !formData.taskId || String(formData.taskId).trim() === '') {
      return { success: false, message: 'Task ID is required' };
    }
    if (!formData.assignee || String(formData.assignee).trim() === '') {
      return { success: false, message: 'New Assignee is required' };
    }

    const sheet = openSheet(CONFIG.DELEGATION_SPREADSHEET_ID, CONFIG.DELEGATION_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < CONFIG.DELEGATION_START_ROW) return { success: false, message: 'No tasks found' };

    const numRows = lastRow - CONFIG.DELEGATION_START_ROW + 1;
    const idValues = sheet.getRange(CONFIG.DELEGATION_START_ROW, 1, numRows, 1).getValues();
    const targetId = String(formData.taskId).trim();
    let targetRow = -1;
    for (let i = 0; i < idValues.length; i++) {
      if (String(idValues[i][0]).trim() === targetId) { targetRow = i + CONFIG.DELEGATION_START_ROW; break; }
    }
    if (targetRow === -1) return { success: false, message: 'Task ID not found' };

    const newAssignee = String(formData.assignee).trim();
    const oldAssignee = sheet.getRange(targetRow, 4).getValue();
    const oldAssigneeStr = oldAssignee ? String(oldAssignee).trim() : '';

    if (newAssignee === oldAssigneeStr) {
      return { success: false, message: 'New assignee is the same as the current assignee' };
    }

    sheet.getRange(targetRow, 4).setValue(sanitize(newAssignee));

    return successResponse({
      row: targetRow,
      oldAssignee: oldAssigneeStr,
      newAssignee: newAssignee
    }, 'Assignee changed successfully');
  } catch (err) {
    return handleError(err, 'changeDelegationAssignee');
  }
}

function updateDelegationTargetDate(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!isAdminOrEA_(session.data.userRole)) {
      return { success: false, message: 'Only Admin or EA can update target date' };
    }

    if (!formData || !formData.taskId || String(formData.taskId).trim() === '') {
      return { success: false, message: 'Task ID is required' };
    }
    if (!formData.targetDate || String(formData.targetDate).trim() === '') {
      return { success: false, message: 'Target Date is required' };
    }

    const newTarget = new Date(formData.targetDate);
    if (isNaN(newTarget.getTime())) {
      return { success: false, message: 'Invalid Target Date' };
    }

    const sheet = openSheet(CONFIG.DELEGATION_SPREADSHEET_ID, CONFIG.DELEGATION_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < CONFIG.DELEGATION_START_ROW) return { success: false, message: 'No tasks found' };

    const numRows = lastRow - CONFIG.DELEGATION_START_ROW + 1;
    const idValues = sheet.getRange(CONFIG.DELEGATION_START_ROW, 1, numRows, 1).getValues();
    const targetId = String(formData.taskId).trim();
    let targetRow = -1;
    for (let i = 0; i < idValues.length; i++) {
      if (String(idValues[i][0]).trim() === targetId) { targetRow = i + CONFIG.DELEGATION_START_ROW; break; }
    }
    if (targetRow === -1) return { success: false, message: 'Task ID not found' };

    sheet.getRange(targetRow, 7).setValue(newTarget);
    sheet.getRange(targetRow, 14).setValue(newTarget);

    const revVal = sheet.getRange(targetRow, 8).getValue();
    let revisionCount = (revVal === '' || revVal === null || revVal === undefined) ? 0 : (parseInt(revVal, 10) || 0);
    revisionCount += 1;
    sheet.getRange(targetRow, 8).setValue(revisionCount);

    return successResponse({ row: targetRow, revisionCount: revisionCount }, 'Target date updated successfully');
  } catch (err) {
    return handleError(err, 'updateDelegationTargetDate');
  }
}

function getDelegationDoerList(token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const sheet = openSheet(CONFIG.DOER_LIST_SPREADSHEET_ID, CONFIG.DOER_LIST_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return successResponse([]);

    ensureUserStatusColumn_(sheet);
    const width = Math.max(CONFIG.DOER_LIST_COLUMNS, CONFIG.DOER_LIST_STATUS_COL);
    const values = sheet.getRange(2, 1, lastRow - 1, width).getValues();

    const cleaned = Array.from(new Set(
      values
        .filter(row => ((row[4] || '').toString().trim().toLowerCase() !== 'inactive'))
        .map(row => (row[0] || '').toString().trim())
        .filter(v => v !== '')
    )).sort((a, b) => a.localeCompare(b));

    return successResponse(cleaned, 'Doer list loaded');
  } catch (err) {
    return handleError(err, 'getDelegationDoerList');
  }
}

// ====================== DASHBOARD (legacy) ======================

function getDashboardStats(doerFilter, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const masterResponse = getMasterTasks(token);
    let masterTasks = masterResponse.success ? masterResponse.data : [];
    if (doerFilter && doerFilter !== 'ALL') {
      masterTasks = masterTasks.filter(t => t.responsiblePerson === doerFilter);
    }
    const checklist = computeModuleStats(masterTasks);

    return successResponse({
      overall: {
        total: checklist.total,
        completed: checklist.completed,
        pending: checklist.pending,
        overdue: checklist.overdue
      },
      checklist: checklist,
      delegation: { total: 0, completed: 0, pending: 0, overdue: 0, revised: 0 },
      helpTicket: computeModuleStats([]),
      appliedDoerFilter: doerFilter || 'ALL'
    }, 'Dashboard stats calculated');
  } catch (err) {
    return handleError(err, 'getDashboardStats');
  }
}

function getResponsiblePersonList(token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const masterResponse = getMasterTasks(token);
    if (!masterResponse.success) throw new Error(masterResponse.message);
    const masterNames = masterResponse.data.map(t => t.responsiblePerson).filter(Boolean);

    const names = Array.from(new Set(masterNames)).sort((a, b) => a.localeCompare(b));
    return successResponse(names, 'Doer names loaded');
  } catch (err) {
    return handleError(err, 'getResponsiblePersonList');
  }
}

function computeModuleStats(tasks) {
  const stats = { total: tasks.length, completed: 0, pending: 0, overdue: 0 };
  tasks.forEach(t => {
    if (t.status === 'COMPLETED' || t.status === 'VERIFIED') stats.completed++;
    else if (t.status === 'OVERDUE') stats.overdue++;
    else stats.pending++;
  });
  return stats;
}

// ====================== DASHBOARD V2 ======================

function getDashboardStatsV2(params, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    params = params || {};
    const trendDays = params.trendDays || 7;

    const currentUser = (session.data.userName || '').toString().trim();
    const role = session.data.userRole;

    const masterRes = getMasterTasks(token);
    const masterTasks = masterRes.success ? masterRes.data : [];

    const checklistTasks = masterTasks.map(m => ({
      source: 'checklist',
      taskId: m.taskId,
      task: m.task,
      responsiblePerson: m.responsiblePerson,
      frequency: m.frequency,
      status: m.status,
      isCompleted: m.isCompleted,
      plannedDateTime: m.plannedDateTime,
      completionDateTime: m.completionDateTime,
      isRevised: false
    }));

    const delegationTasks = getAllDelegationTasksForStats(currentUser, role);

    const helpTicketTasks = getHelpTicketTasksForDashboard(currentUser, role);

    const allTasks = checklistTasks.concat(delegationTasks).concat(helpTicketTasks);

    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0).getTime();
    const todayEnd = todayStart + 86400000;

    let overall = {
      total: 0, completed: 0, pending: 0, overdue: 0, revised: 0,
      onTime: 0, delayed: 0, completionPct: 0, onTimePct: 0
    };
    let today = { total: 0, completed: 0, pending: 0, overdue: 0, dueToday: 0 };

    allTasks.forEach(t => {
      overall.total++;
      if (t.status === 'COMPLETED' || t.status === 'VERIFIED') {
        overall.completed++;
        if (t.completionDateTime && t.plannedDateTime) {
          if (t.completionDateTime <= t.plannedDateTime) overall.onTime++;
          else overall.delayed++;
        }
      } else if (t.status === 'OVERDUE') {
        overall.overdue++;
      } else {
        overall.pending++;
      }
      if (t.isRevised) overall.revised++;

      const plannedToday = t.plannedDateTime &&
        t.plannedDateTime >= todayStart && t.plannedDateTime < todayEnd;
      const completedToday = t.completionDateTime &&
        t.completionDateTime >= todayStart && t.completionDateTime < todayEnd;
      if (plannedToday || completedToday) {
        today.total++;
        if (t.status === 'COMPLETED' || t.status === 'VERIFIED') today.completed++;
        else if (t.status === 'OVERDUE') today.overdue++;
        else today.pending++;
      }
      if (plannedToday) today.dueToday++;
    });

    overall.completionPct = overall.total > 0
      ? roundOneDecimal((overall.completed / overall.total) * 100) : 0;
    overall.onTimePct = overall.completed > 0
      ? roundOneDecimal((overall.onTime / overall.completed) * 100) : 0;

    const buildModule = (list) => {
      const s = { total: list.length, completed: 0, pending: 0, overdue: 0 };
      list.forEach(t => {
        if (t.status === 'COMPLETED' || t.status === 'VERIFIED') s.completed++;
        else if (t.status === 'OVERDUE') s.overdue++;
        else s.pending++;
      });
      s.completionPct = s.total > 0
        ? roundOneDecimal((s.completed / s.total) * 100) : 0;
      return s;
    };
    const modules = {
      checklist: buildModule(checklistTasks),
      delegation: buildModule(delegationTasks),
      helpTicket: buildModule(helpTicketTasks)
    };

    const doerMap = {};
    allTasks.forEach(t => {
      const doer = t.responsiblePerson || 'Unassigned';
      if (!doerMap[doer]) doerMap[doer] = { doer: doer };
    });
    const doers = Object.keys(doerMap).map(k => ({ doer: k })).sort((a, b) => a.doer.localeCompare(b.doer));

    const trend = computeTaskTrend(allTasks, trendDays);
    const overdueAging = computeOverdueAging(allTasks, now);
    const recentActivity = computeRecentActivity(allTasks, 8);

    const misScore = {
      score: roundOneDecimal((overall.completionPct * 0.6) + (overall.onTimePct * 0.4)),
      completionPct: overall.completionPct,
      onTimePct: overall.onTimePct,
      pendingPct: overall.total > 0
        ? roundOneDecimal((overall.pending / overall.total) * 100) : 0,
      delayedPct: overall.completed > 0
        ? roundOneDecimal((overall.delayed / overall.completed) * 100) : 0
    };

    return successResponse({
      overall: overall,
      today: today,
      modules: modules,
      doers: doers,
      trend: trend,
      overdueAging: overdueAging,
      recentActivity: recentActivity,
      misScore: misScore,
      period: { type: 'all', from: null, to: null, label: 'All Time' }
    }, 'Dashboard V2 loaded');
  } catch (err) {
    return handleError(err, 'getDashboardStatsV2');
  }
}

function getHelpTicketTasksForDashboard(currentUser, role) {
  try {
    const prSheet = htOpenSheet_(HELP_TICKET_CONFIG.PROCESS_SHEET);
    const htSheet = htOpenSheet_(HELP_TICKET_CONFIG.HELP_TICKET_SHEET);

    const lastRow = prSheet.getLastRow();
    if (lastRow < 2) return [];

    const values = prSheet.getRange(2, 1, lastRow - 1, 11).getValues();

    const now = new Date();
    const isAdmin = isAdminRole_(role);
    const isEA = isEARole_(role);
    const filterUser = (currentUser || '').toString().trim().toLowerCase();

    const assignedToMap = {};
    const htLast = htSheet.getLastRow();
    if (htLast >= 2) {
      const htValues = htSheet.getRange(2, 1, htLast - 1, 5).getValues();
      htValues.forEach(r => {
        const tid = String(r[1] || '').trim();
        if (tid !== '') assignedToMap[tid] = (r[4] || '').toString().trim();
      });
    }

    const stepIndexByTicket = {};
    const tasks = [];

    for (let i = 0; i < values.length; i++) {
      const r = values[i];
      const ticketId = (r[0] || '').toString().trim();
      if (ticketId === '') continue;

      const stepName = (r[1] || '').toString().trim();
      if (stepName === '') continue;

      if (!stepIndexByTicket[ticketId]) stepIndexByTicket[ticketId] = [];
      stepIndexByTicket[ticketId].push(i);

      const idx = stepIndexByTicket[ticketId].length - 1;
      let who = (r[3] || '').toString().trim();
      if (idx === 1) {
        const assignedTo = assignedToMap[ticketId];
        if (assignedTo) who = assignedTo;
      }
      if (who === '') continue;

      if (isAdmin) {
        // all
      } else if (isEA) {
        // all
      } else {
        if (who.toLowerCase() !== filterUser) continue;
      }

      const plannedRaw = r[6];
      const actualRaw = r[7];
      const statusRaw = (r[8] || '').toString().trim();

      const plannedDate = parseCompletionDateTime(plannedRaw);
      const actualDate = parseCompletionDateTime(actualRaw);

      const isCompleted = (statusRaw === HELP_TICKET_CONFIG.STATUS_COMPLETED)
                          && actualDate !== null;

      let status;
      if (isCompleted) {
        status = 'COMPLETED';
      } else if (plannedDate && plannedDate.getTime() < now.getTime()) {
        status = 'OVERDUE';
      } else {
        status = 'PENDING';
      }

      tasks.push({
        source: 'helpTicket',
        taskId: ticketId,
        step: stepName,
        task: stepName,
        responsiblePerson: who,
        frequency: '',
        status: status,
        isCompleted: isCompleted,
        plannedDateTime: plannedDate ? plannedDate.getTime() : null,
        completionDateTime: actualDate ? actualDate.getTime() : null,
        isRevised: false
      });
    }

    return tasks;
  } catch (err) {
    console.error('[getHelpTicketTasksForDashboard] ' + (err && err.message ? err.message : err));
    return [];
  }
}

function computeTaskTrend(tasks, days) {
  const buckets = [];
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

  for (let i = days - 1; i >= 0; i--) {
    const dayStart = todayStart - (i * 86400000);
    buckets.push({
      date: dayStart,
      label: formatDateOnly(new Date(dayStart)),
      created: 0, completed: 0, pending: 0, overdue: 0
    });
  }

  tasks.forEach(t => {
    if (t.plannedDateTime) {
      const idx = Math.floor((t.plannedDateTime - todayStart) / 86400000) + (days - 1);
      if (idx >= 0 && idx < days) buckets[idx].created++;
    }
    if (t.completionDateTime) {
      const idx = Math.floor((t.completionDateTime - todayStart) / 86400000) + (days - 1);
      if (idx >= 0 && idx < days) buckets[idx].completed++;
    }
    if (!t.isCompleted) {
      if (t.status === 'OVERDUE') buckets[days - 1].overdue++;
      else buckets[days - 1].pending++;
    }
  });

  return buckets;
}

function computeOverdueAging(tasks, now) {
  const buckets = [
    { label: '0-4 Hours', count: 0, min: 0, max: 4 },
    { label: '4-12 Hours', count: 0, min: 4, max: 12 },
    { label: '12-24 Hours', count: 0, min: 12, max: 24 },
    { label: '1-3 Days', count: 0, min: 24, max: 72 },
    { label: '3+ Days', count: 0, min: 72, max: Infinity }
  ];

  tasks.forEach(t => {
    if (t.isCompleted) return;
    if (t.status !== 'OVERDUE') return;
    if (!t.plannedDateTime) return;
    const hoursOverdue = (now.getTime() - t.plannedDateTime) / 3600000;
    for (let i = 0; i < buckets.length; i++) {
      if (hoursOverdue >= buckets[i].min && hoursOverdue < buckets[i].max) {
        buckets[i].count++;
        break;
      }
    }
  });

  return buckets.map(b => ({ label: b.label, count: b.count }));
}

function computeRecentActivity(tasks, limit) {
  const events = [];

  tasks.forEach(t => {
    if (t.completionDateTime) {
      const sourceLabel = (t.source === 'delegation') ? 'Delegation'
                        : (t.source === 'helpTicket') ? 'Help Ticket'
                        : 'Checklist';
      const stepSuffix = (t.source === 'helpTicket' && t.step) ? ' (' + t.step + ')' : '';
      events.push({
        time: t.completionDateTime,
        text: (t.responsiblePerson || 'Unknown') + ' completed ' + sourceLabel + ' #' + t.taskId + stepSuffix
      });
    }
  });

  events.sort((a, b) => b.time - a.time);

  return events.slice(0, limit).map(e => ({
    time: e.time,
    timeDisplay: e.time ? formatTimeOnly(new Date(e.time)) : '—',
    text: e.text
  }));
}

// ====================== MIS SCORING ======================

function getMisScoring(params, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const periodType = (params && params.periodType) || 'monthly';
    const range = computePeriodRange(periodType, params && params.customFrom, params && params.customTo);
    const doerFilter = params && params.doerFilter;

    const currentUser = (session.data.userName || '').toString().trim();
    const role = session.data.userRole;

    const tasksResponse = getMasterTasks(token);
    if (!tasksResponse.success) throw new Error(tasksResponse.message);

    let checklistInRange = tasksResponse.data.filter(t =>
      t.plannedDateTime !== null &&
      t.plannedDateTime >= range.from.getTime() &&
      t.plannedDateTime <= range.to.getTime()
    );
    if (doerFilter && doerFilter !== 'ALL') {
      checklistInRange = checklistInRange.filter(t => t.responsiblePerson === doerFilter);
    }

    let delegationInRange = getAllDelegationTasksForStats(currentUser, role).filter(t =>
      t.plannedDateTime !== null &&
      t.plannedDateTime >= range.from.getTime() &&
      t.plannedDateTime <= range.to.getTime()
    );
    if (doerFilter && doerFilter !== 'ALL') {
      delegationInRange = delegationInRange.filter(t => t.responsiblePerson === doerFilter);
    }

    const helpTicketTasks = getHelpTicketTasksForStats(doerFilter, range);

    return successResponse({
      period: {
        type: periodType,
        from: range.from.getTime(),
        to: range.to.getTime(),
        label: range.label
      },
      appliedDoerFilter: doerFilter || 'ALL',
      modules: {
        checklist: computeDoerScores(checklistInRange),
        delegation: computeDoerScores(delegationInRange),
        helpTicket: computeDoerScores(helpTicketTasks)
      }
    }, 'MIS scoring calculated');
  } catch (err) {
    return handleError(err, 'getMisScoring');
  }
}

function computeDoerScores(tasks) {
  const map = {};
  tasks.forEach(t => {
    const doer = t.responsiblePerson || 'Unassigned';
    if (!map[doer]) map[doer] = { doer: doer, total: 0, completeTask: 0, pendingTask: 0, ontimeTask: 0, delayCompleteTask: 0 };
    const d = map[doer];
    d.total++;
    if (t.status === 'COMPLETED' || t.status === 'VERIFIED') {
      d.completeTask++;
      if (t.completionDateTime !== null && t.plannedDateTime !== null) {
        if (t.completionDateTime <= t.plannedDateTime) d.ontimeTask++;
        else d.delayCompleteTask++;
      }
    } else {
      d.pendingTask++;
    }
  });
  return Object.keys(map).map(doer => {
    const d = map[doer];
    d.totalVsCompletePct = d.total > 0 ? roundOneDecimal((d.completeTask / d.total) * 100) : 0;
    d.completeVsOntimePct = d.completeTask > 0 ? roundOneDecimal((d.ontimeTask / d.completeTask) * 100) : 0;
    return d;
  }).sort((a, b) => b.totalVsCompletePct - a.totalVsCompletePct);
}

function roundOneDecimal(n) { return Math.round(n * 10) / 10; }

function computePeriodRange(periodType, customFrom, customTo) {
  const now = new Date();
  let from = null, to = null, label = 'All Time';

  if (periodType === 'all') {
    return { from: null, to: null, label: 'All Time' };
  }

  if (periodType === 'today') {
    from = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
    to = new Date(from.getFullYear(), from.getMonth(), from.getDate(), 23, 59, 59, 999);
    label = 'Today';
  } else if (periodType === 'yesterday') {
    from = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 0, 0, 0, 0);
    to = new Date(from.getFullYear(), from.getMonth(), from.getDate(), 23, 59, 59, 999);
    label = 'Yesterday';
  } else if (periodType === 'custom') {
    from = customFrom ? new Date(customFrom) : new Date(now.getFullYear(), now.getMonth(), 1);
    to = customTo ? new Date(customTo) : now;
    from.setHours(0, 0, 0, 0);
    to.setHours(23, 59, 59, 999);
    return { from, to, label: 'Custom (' + formatDateOnly(from) + ' – ' + formatDateOnly(to) + ')' };
  } else if (periodType === 'weekly') {
    const day = now.getDay();
    const diffToMonday = (day === 0 ? -6 : 1 - day);
    from = new Date(now.getFullYear(), now.getMonth(), now.getDate() + diffToMonday, 0, 0, 0, 0);
    to = new Date(from.getFullYear(), from.getMonth(), from.getDate() + 6, 23, 59, 59, 999);
    label = 'This Week (' + formatDateOnly(from) + ' – ' + formatDateOnly(to) + ')';
  } else if (periodType === 'lastweek') {
    const day = now.getDay();
    const diffToMonday = (day === 0 ? -6 : 1 - day);
    const thisMon = new Date(now.getFullYear(), now.getMonth(), now.getDate() + diffToMonday, 0, 0, 0, 0);
    from = new Date(thisMon.getTime() - 7 * 86400000);
    to = new Date(thisMon.getTime() - 1);
    label = 'Last Week';
  } else if (periodType === 'monthly') {
    from = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
    to = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
    label = 'This Month (' + now.toLocaleString('en-US', { month: 'long' }) + ' ' + now.getFullYear() + ')';
  } else if (periodType === 'lastmonth') {
    from = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
    to = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
    label = 'Last Month';
  } else if (periodType === 'quarterly') {
    const q = Math.floor(now.getMonth() / 3);
    from = new Date(now.getFullYear(), q * 3, 1, 0, 0, 0, 0);
    to = new Date(now.getFullYear(), q * 3 + 3, 0, 23, 59, 59, 999);
    label = 'Q' + (q + 1) + ' ' + now.getFullYear();
  } else if (periodType === 'halfyearly') {
    const half = now.getMonth() < 6 ? 0 : 1;
    from = new Date(now.getFullYear(), half * 6, 1, 0, 0, 0, 0);
    to = new Date(now.getFullYear(), half * 6 + 6, 0, 23, 59, 59, 999);
    label = (half === 0 ? 'H1 ' : 'H2 ') + now.getFullYear();
  } else if (periodType === 'yearly') {
    from = new Date(now.getFullYear(), 0, 1, 0, 0, 0, 0);
    to = new Date(now.getFullYear(), 11, 31, 23, 59, 59, 999);
    label = 'Year ' + now.getFullYear();
  } else {
    return { from: null, to: null, label: 'All Time' };
  }
  return { from, to, label };
}

// ====================== DOER LIST ======================

function getDoerList(token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const sheet = openSheet(CONFIG.DOER_LIST_SPREADSHEET_ID, CONFIG.DOER_LIST_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return successResponse([]);

    ensureUserStatusColumn_(sheet);
    const width = Math.max(CONFIG.DOER_LIST_COLUMNS, CONFIG.DOER_LIST_STATUS_COL);
    const values = sheet.getRange(2, 1, lastRow - 1, width).getValues();

    const cleaned = Array.from(new Set(
      values
        .filter(row => ((row[4] || '').toString().trim().toLowerCase() !== 'inactive'))
        .map(row => (row[0] || '').toString().trim())
        .filter(v => v !== '')
    )).sort((a, b) => a.localeCompare(b));

    return successResponse(cleaned, 'Doer list loaded');
  } catch (err) {
    return handleError(err, 'getDoerList');
  }
}

// ====================== USER LIST ======================

function ensureUserStatusColumn_(sheet) {
  const lastCol = Math.max(sheet.getLastColumn(), CONFIG.DOER_LIST_COLUMNS);
  if (lastCol < CONFIG.DOER_LIST_STATUS_COL) {
    sheet.getRange(1, CONFIG.DOER_LIST_STATUS_COL).setValue('Status');
  }
  return CONFIG.DOER_LIST_STATUS_COL;
}

function getUserListWithStatus_(sheet) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  ensureUserStatusColumn_(sheet);
  const width = Math.max(CONFIG.DOER_LIST_COLUMNS, CONFIG.DOER_LIST_STATUS_COL);
  const values = sheet.getRange(2, 1, lastRow - 1, width).getValues();
  return values.map((row, idx) => ({
    rowNumber: idx + 2,
    name: (row[0] || '').toString().trim(),
    mobileNo: (row[1] || '').toString().trim(),
    emailId: (row[2] || '').toString().trim(),
    password: (row[3] || '').toString(),
    status: (row[4] || '').toString().trim() || 'Active'
  }));
}

function getUserList(token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const sheet = openSheet(CONFIG.DOER_LIST_SPREADSHEET_ID, CONFIG.DOER_LIST_SHEET);
    let users = getUserListWithStatus_(sheet).filter(u => u.name !== '' || u.emailId !== '');

    const currentUser = (session.data.userName || '').toString().trim().toLowerCase();
    const isAdmin = isAdminRole_(session.data.userRole);

    if (!isAdmin) {
      users = users.filter(u => u.name.toLowerCase() === currentUser);
    }

    return successResponse(users, 'User list loaded');
  } catch (err) {
    return handleError(err, 'getUserList');
  }
}

function addDoerUser(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!isAdminRole_(session.data.userRole)) {
      return { success: false, message: 'Only Admin can add users' };
    }

    if (!formData || !formData.name || formData.name.toString().trim() === '') {
      return { success: false, message: 'Name is required' };
    }
    if (!formData.password || formData.password.toString().trim().length < 4) {
      return { success: false, message: 'Password must be at least 4 characters' };
    }

    const sheet = openSheet(CONFIG.DOER_LIST_SPREADSHEET_ID, CONFIG.DOER_LIST_SHEET);
    ensureUserStatusColumn_(sheet);
    const lastRow = sheet.getLastRow();
    const targetRow = Math.max(lastRow + 1, 2);

    sheet.getRange(targetRow, 1, 1, CONFIG.DOER_LIST_STATUS_COL).setValues([[
      sanitize(formData.name),
      sanitize(formData.mobileNo),
      sanitize(formData.emailId),
      sanitize(formData.password),
      'Active'
    ]]);

    return successResponse({ row: targetRow }, 'User added successfully');
  } catch (err) {
    return handleError(err, 'addDoerUser');
  }
}

function updateDoerUser(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!isAdminRole_(session.data.userRole)) {
      return { success: false, message: 'Only Admin can edit users' };
    }

    if (!formData || !formData.rowNumber) {
      return { success: false, message: 'Row number is required' };
    }
    if (!formData.name || formData.name.toString().trim() === '') {
      return { success: false, message: 'Name is required' };
    }

    const newPass = formData.password ? formData.password.toString() : '';
    if (newPass !== '' && newPass.trim().length < 4) {
      return { success: false, message: 'Password must be at least 4 characters' };
    }

    const sheet = openSheet(CONFIG.DOER_LIST_SPREADSHEET_ID, CONFIG.DOER_LIST_SHEET);
    const lastRow = sheet.getLastRow();
    const targetRow = parseInt(formData.rowNumber, 10);
    if (isNaN(targetRow) || targetRow < 2 || targetRow > lastRow) {
      return { success: false, message: 'Invalid row number' };
    }

    const current = sheet.getRange(targetRow, 1, 1, CONFIG.DOER_LIST_COLUMNS).getValues()[0];
    const currentName = (current[0] || '').toString().trim().toLowerCase();
    const originalName = (formData.originalName || '').toString().trim().toLowerCase();
    if (originalName && currentName !== originalName) {
      return { success: false, message: 'Row mismatch. Please refresh and try again.' };
    }

    const newNameLower = formData.name.toString().trim().toLowerCase();
    const names = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
    for (let i = 0; i < names.length; i++) {
      if (i + 2 === targetRow) continue;
      if ((names[i][0] || '').toString().trim().toLowerCase() === newNameLower) {
        return { success: false, message: 'Another user with this name already exists' };
      }
    }

    sheet.getRange(targetRow, 1, 1, 3).setValues([[
      sanitize(formData.name),
      sanitize(formData.mobileNo),
      sanitize(formData.emailId)
    ]]);

    if (newPass !== '') {
      sheet.getRange(targetRow, 4).setValue(sanitize(newPass));
    }

    return successResponse({ row: targetRow }, 'User updated successfully');
  } catch (err) {
    return handleError(err, 'updateDoerUser');
  }
}

function setDoerUserInactive(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };
    if (!isAdminRole_(session.data.userRole)) {
      return { success: false, message: 'Only Admin can deactivate users' };
    }
    if (!formData || !formData.rowNumber) {
      return { success: false, message: 'Row number is required' };
    }

    const sheet = openSheet(CONFIG.DOER_LIST_SPREADSHEET_ID, CONFIG.DOER_LIST_SHEET);
    const targetRow = parseInt(formData.rowNumber, 10);
    if (isNaN(targetRow) || targetRow < 2) {
      return { success: false, message: 'Invalid row number' };
    }

    ensureUserStatusColumn_(sheet);
    sheet.getRange(targetRow, CONFIG.DOER_LIST_STATUS_COL).setValue('Inactive');

    return successResponse({ row: targetRow }, 'User set to Inactive');
  } catch (err) {
    return handleError(err, 'setDoerUserInactive');
  }
}

function changeDoerPassword(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!formData) return { success: false, message: 'No data received' };
    if (!formData.newPassword || formData.newPassword.toString().trim().length < 4) {
      return { success: false, message: 'New password must be at least 4 characters' };
    }

    const sheet = openSheet(CONFIG.DOER_LIST_SPREADSHEET_ID, CONFIG.DOER_LIST_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return { success: false, message: 'No users found' };

    const values = sheet.getRange(2, 1, lastRow - 1, CONFIG.DOER_LIST_COLUMNS).getValues();
    const targetName = (formData.name || '').toString().trim().toLowerCase();
    const targetEmail = (formData.emailId || '').toString().trim().toLowerCase();

    let targetRow = -1;
    for (let i = 0; i < values.length; i++) {
      const rowName = (values[i][0] || '').toString().trim().toLowerCase();
      const rowEmail = (values[i][2] || '').toString().trim().toLowerCase();
      if (targetName && rowName === targetName) { targetRow = i + 2; break; }
      if (targetEmail && rowEmail === targetEmail) { targetRow = i + 2; break; }
    }

    if (targetRow === -1) {
      return { success: false, message: 'User not found by the given name or email' };
    }

    sheet.getRange(targetRow, 4).setValue(sanitize(formData.newPassword));
    return successResponse({ row: targetRow }, 'Password updated successfully');
  } catch (err) {
    return handleError(err, 'changeDoerPassword');
  }
}

// ====================== CREATE TASK (Admin or EA) ======================

function createTask(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!isAdminOrEA_(session.data.userRole)) {
      return { success: false, message: 'Only Admin or EA can add tasks' };
    }

    const errors = validateTaskForm(formData);
    if (errors.length > 0) {
      return { success: false, message: 'Validation failed', error: errors.join('; ') };
    }

    let ss;
    try {
      ss = SpreadsheetApp.openById(CONFIG.TASK_LIST_SPREADSHEET_ID);
    } catch (e) {
      return {
        success: false,
        message: 'Cannot open Task List spreadsheet. Check sharing/permissions.',
        error: e && e.message ? e.message : String(e)
      };
    }

    const sheet = ss.getSheetByName(CONFIG.TASK_LIST_SHEET);
    if (!sheet) {
      const available = ss.getSheets().map(s => '"' + s.getName() + '"').join(', ');
      return {
        success: false,
        message: 'Sheet "' + CONFIG.TASK_LIST_SHEET + '" not found.',
        error: 'Available sheets: ' + available
      };
    }

    const targetRow = Math.max(sheet.getLastRow() + 1, 2);
    const targetRange = sheet.getRange(
      targetRow,
      CONFIG.TASK_LIST_START_COL,
      1,
      CONFIG.TASK_LIST_COLUMNS
    );

    try { targetRange.clearDataValidations(); } catch (e) {}

    targetRange.setValues([[
      sanitize(formData.task),
      sanitize(formData.holidayPriority),
      sanitize(formData.doerName),
      sanitize(formData.department),
      sanitize(formData.timing),
      sanitize(formData.frequency),
      sanitize(formData.schedule),
      sanitize(formData.startDate),
      sanitize(formData.endDate)
    ]]);

    return successResponse({ row: targetRow }, 'Task created successfully');
  } catch (err) {
    return {
      success: false,
      message: 'Save failed: ' + (err && err.message ? err.message : String(err)),
      error: (err && err.stack) ? err.stack : String(err)
    };
  }
}

function validateTaskForm(formData) {
  const errors = [];
  if (!formData) return ['No form data received'];
  if (!formData.task || !formData.task.toString().trim()) errors.push('Task is required');
  if (formData.task && formData.task.toString().length > 500) errors.push('Task text too long (max 500 characters)');
  if (!CONFIG.VALID_HOLIDAY_PRIORITY.includes(formData.holidayPriority)) {
    errors.push('Holiday Priority must be "After" or "Before"');
  }
  if (!formData.doerName || !formData.doerName.toString().trim()) errors.push('Doer Name is required');
  if (!formData.department || !formData.department.toString().trim()) errors.push('Department is required');
  if (!formData.timing || !formData.timing.toString().trim()) errors.push('Timing is required');
  if (!CONFIG.VALID_FREQUENCIES.includes(formData.frequency)) {
    errors.push('Frequency must be one of: ' + CONFIG.VALID_FREQUENCIES.join(', '));
  }
  if (!formData.schedule || !formData.schedule.toString().trim()) errors.push('Schedule is required');
  if (formData.schedule && formData.schedule.toString().length > 300) errors.push('Schedule text too long (max 300 characters)');
  return errors;
}

// ====================== MASTER TASKLIST MODULE ======================

function getMasterTasklist(token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!isAdminOrEA_(session.data.userRole)) {
      return { success: false, message: 'Access denied' };
    }

    const sheet = openSheet(CONFIG.TASK_LIST_SPREADSHEET_ID, CONFIG.TASK_LIST_SHEET);
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return successResponse([]);

    const range = sheet.getRange(2, 1, lastRow - 1, 10);

    const values = range.getValues();
    const displayValues = range.getDisplayValues();

    const tasks = values.map((row, idx) => {
      const taskId = row[0];
      if (taskId === '' || taskId === null || taskId === undefined) return null;

      const scheduleDisplay = displayValues[idx][7] || '';

      return {
        rowNumber: idx + 2,
        taskId: String(taskId),
        task: row[1] ? String(row[1]) : '',
        holidayPriority: row[2] ? String(row[2]) : '',
        doerName: row[3] ? String(row[3]) : '',
        department: row[4] ? String(row[4]) : '',
        timing: formatSheetTiming(row[5]),
        frequency: row[6] ? String(row[6]) : '',
        schedule: scheduleDisplay,
        startDate: row[8] ? formatSheetDate(row[8]) : '',
        endDate: row[9] ? formatSheetDate(row[9]) : ''
      };
    }).filter(t => t !== null);

    return successResponse(tasks, 'Master tasklist loaded');
  } catch (err) {
    return handleError(err, 'getMasterTasklist');
  }
}

function formatSheetTiming(value) {
  if (value === null || value === undefined || value === '') return '';

  if (value instanceof Date) {
    const pad = n => String(n).padStart(2, '0');
    return pad(value.getHours()) + ':' + pad(value.getMinutes()) + ':' + pad(value.getSeconds());
  }

  const str = String(value).trim();
  if (str === '') return '';

  const hmsMatch = str.match(/^(\d{1,2}):(\d{2}):(\d{2})$/);
  if (hmsMatch) {
    const pad = n => String(n).padStart(2, '0');
    return pad(parseInt(hmsMatch[1], 10)) + ':' + hmsMatch[2] + ':' + hmsMatch[3];
  }

  const hmMatch = str.match(/^(\d{1,2}):(\d{2})$/);
  if (hmMatch) {
    const pad = n => String(n).padStart(2, '0');
    return pad(parseInt(hmMatch[1], 10)) + ':' + hmMatch[2] + ':00';
  }

  const ampmMatch = str.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)$/i);
  if (ampmMatch) {
    let h = parseInt(ampmMatch[1], 10);
    const m = ampmMatch[2];
    const s = ampmMatch[3] ? ampmMatch[3] : '00';
    const ampm = ampmMatch[4].toUpperCase();
    if (ampm === 'PM' && h < 12) h += 12;
    if (ampm === 'AM' && h === 12) h = 0;
    const pad = n => String(n).padStart(2, '0');
    return pad(h) + ':' + m + ':' + s;
  }

  return str;
}

function formatSheetDate(value) {
  if (value === null || value === undefined || value === '') return '';
  if (value instanceof Date) {
    const pad = n => String(n).padStart(2, '0');
    return pad(value.getDate()) + '-' + pad(value.getMonth() + 1) + '-' + value.getFullYear();
  }
  return String(value).trim();
}

function updateMasterTasklistTask(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!isAdminOrEA_(session.data.userRole)) {
      return { success: false, message: 'Access denied' };
    }

    if (!formData || !formData.rowNumber) {
      return { success: false, message: 'Row number is required' };
    }
    if (!formData.taskId || String(formData.taskId).trim() === '') {
      return { success: false, message: 'Task id is required' };
    }

    const sheet = openSheet(CONFIG.TASK_LIST_SPREADSHEET_ID, CONFIG.TASK_LIST_SHEET);
    const targetRow = parseInt(formData.rowNumber, 10);

    if (isNaN(targetRow) || targetRow < 2) {
      return { success: false, message: 'Invalid row number' };
    }

    const existingId = sheet.getRange(targetRow, 1).getValue();
    if (String(existingId).trim() !== String(formData.taskId).trim()) {
      return { success: false, message: 'Row mismatch. Please refresh and try again.' };
    }

    sheet.getRange(targetRow, 2, 1, 9).setValues([[
      sanitize(formData.task),
      sanitize(formData.holidayPriority),
      sanitize(formData.doerName),
      sanitize(formData.department),
      sanitize(formData.timing),
      sanitize(formData.frequency),
      (formData.schedule === null || formData.schedule === undefined)
        ? ''
        : String(formData.schedule).replace(/</g, '').replace(/>/g, ''),
      sanitize(formData.startDate),
      sanitize(formData.endDate)
    ]]);

    return successResponse({ row: targetRow }, 'Task updated successfully');
  } catch (err) {
    return handleError(err, 'updateMasterTasklistTask');
  }
}

function deleteMasterTasklistTask(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!isAdminOrEA_(session.data.userRole)) {
      return { success: false, message: 'Access denied' };
    }

    if (!formData || !formData.rowNumber) {
      return { success: false, message: 'Row number is required' };
    }
    if (!formData.taskId || String(formData.taskId).trim() === '') {
      return { success: false, message: 'Task id is required' };
    }

    const sheet = openSheet(CONFIG.TASK_LIST_SPREADSHEET_ID, CONFIG.TASK_LIST_SHEET);
    const targetRow = parseInt(formData.rowNumber, 10);

    if (isNaN(targetRow) || targetRow < 2) {
      return { success: false, message: 'Invalid row number' };
    }

    const existingId = sheet.getRange(targetRow, 1).getValue();
    if (String(existingId).trim() !== String(formData.taskId).trim()) {
      return { success: false, message: 'Row mismatch. Please refresh and try again.' };
    }

    sheet.deleteRow(targetRow);

    return successResponse({ row: targetRow }, 'Task deleted successfully');
  } catch (err) {
    return handleError(err, 'deleteMasterTasklistTask');
  }
}

// ====================== ONE-TIME AUTHORIZATION HELPERS ======================

function testTaskListAccess() {
  const ss = SpreadsheetApp.openById(CONFIG.TASK_LIST_SPREADSHEET_ID);
  const sheet = ss.getSheetByName(CONFIG.TASK_LIST_SHEET);
  const doerSheet = ss.getSheetByName(CONFIG.DOER_LIST_SHEET);
  Logger.log('Spreadsheet name: ' + ss.getName());
  Logger.log('Task List sheet found: ' + (sheet ? 'YES' : 'NO'));
  Logger.log('Doer List sheet found: ' + (doerSheet ? 'YES' : 'NO'));
  if (sheet) {
    Logger.log('Task List last row: ' + sheet.getLastRow());
    Logger.log('Task List last column: ' + sheet.getLastColumn());
  }
  if (doerSheet) {
    Logger.log('Doer List last row: ' + doerSheet.getLastRow());
    Logger.log('Doer List last column: ' + doerSheet.getLastColumn());
  }
}

function testDelegationAccess() {
  const ss = SpreadsheetApp.openById(CONFIG.DELEGATION_SPREADSHEET_ID);
  const sheet = ss.getSheetByName(CONFIG.DELEGATION_SHEET);
  Logger.log('Delegation Spreadsheet name: ' + ss.getName());
  Logger.log('Delegation sheet found: ' + (sheet ? 'YES' : 'NO'));
  if (sheet) {
    Logger.log('Delegation last row: ' + sheet.getLastRow());
    Logger.log('Delegation last column: ' + sheet.getLastColumn());
  }
}

// ====================== UTILITIES ======================

function openSheet(spreadsheetId, sheetName) {
  const ss = SpreadsheetApp.openById(spreadsheetId);
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet) throw new Error('Sheet "' + sheetName + '" not found in spreadsheet ' + spreadsheetId);
  return sheet;
}

function sanitize(value) {
  if (value === null || value === undefined) return '';
  return value.toString().replace(/</g, '').replace(/>/g, '').trim();
}

function successResponse(data, message) {
  return { success: true, message: message || 'OK', data: data };
}

function handleError(err, context) {
  console.error('[' + context + '] ' + (err && err.message ? err.message : err));
  return {
    success: false,
    message: 'Unable to complete request. Please try again.',
    error: (err && err.message) ? err.message : String(err)
  };
}

// ============================================================
// ===== HELP TICKET MODULE (v3.11.2) ========================
// ============================================================

const HELP_TICKET_CONFIG = {
  SPREADSHEET_ID: '1q6HdW0vz1OWguRhwja1kd_WUt8YAyBcRLaQ-FiulJC0',
  HELP_TICKET_SHEET: 'HelpTicket',
  PROCESS_SHEET: 'Process',
  STEP_SHEET: 'Step',
  ID_LOCK_TIMEOUT_MS: 30000,
  STATUS_YES: 'Yes',
  STATUS_NO: 'No',
  STATUS_PENDING: 'Pending',
  STATUS_COMPLETED: 'Completed',
  STATUS_NOT_COMPLETED: 'Not Completed',
  STEP1_FIXED_MS: 1 * 60 * 60 * 1000,
  STEP3PLUS_FIXED_MS: 2 * 60 * 60 * 1000,
  LEAD_TIME_TYPE_DAY: 'Day',
  LEAD_TIME_TYPE_TIME: 'Time'
};

function htOpenSheet_(sheetName) {
  return openSheet(HELP_TICKET_CONFIG.SPREADSHEET_ID, sheetName);
}

function htFormatCell_(x) {
  if (x === '' || x === null || x === undefined) return '';
  if (x instanceof Date) return formatDateTime(x);
  return String(x);
}

function htFormatPlanned_(date) {
  if (!date) return '';
  const d = (date instanceof Date) ? date : new Date(date);
  if (isNaN(d.getTime())) return '';
  const pad = n => String(n).padStart(2, '0');
  return pad(d.getDate()) + '-' + pad(d.getMonth() + 1) + '-' + d.getFullYear() +
         ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}

function htFormatLeadTimeCell_(val) {
  if (val === null || val === undefined || val === '') return '';

  const pad = n => String(n).padStart(2, '0');

  if (val instanceof Date) {
    const h = val.getHours();
    const m = val.getMinutes();
    const s = val.getSeconds();
    return pad(h) + ':' + pad(m) + ':' + pad(s);
  }

  if (typeof val === 'number') {
    const totalSec = Math.round(val * 86400);
    const h = Math.floor(totalSec / 3600) % 24;
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    return pad(h) + ':' + pad(m) + ':' + pad(s);
  }

  const str = String(val).trim();
  if (str === '') return '';

  const hmsMatch = str.match(/^(\d{1,3}):(\d{2}):(\d{2})$/);
  if (hmsMatch) {
    return pad(parseInt(hmsMatch[1], 10)) + ':' + hmsMatch[2] + ':' + hmsMatch[3];
  }

  const hmMatch = str.match(/^(\d{1,3}):(\d{2})$/);
  if (hmMatch) {
    return pad(parseInt(hmMatch[1], 10)) + ':' + hmMatch[2] + ':00';
  }

  const num = Number(str);
  if (!isNaN(num)) {
    const totalSec = Math.round(num * 3600);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    return pad(h) + ':' + pad(m) + ':' + pad(s);
  }

  return str;
}

function htParseWhenDurationMs_(whenVal) {
  if (whenVal === null || whenVal === undefined || whenVal === '') return 0;

  if (whenVal instanceof Date) {
    return (whenVal.getHours() * 3600 + whenVal.getMinutes() * 60 + whenVal.getSeconds()) * 1000;
  }

  const str = String(whenVal).trim();
  if (str === '') return 0;

  const hmsMatch = str.match(/^(\d{1,3}):(\d{2})(?::(\d{2}))?$/);
  if (hmsMatch) {
    const h = parseInt(hmsMatch[1], 10) || 0;
    const m = parseInt(hmsMatch[2], 10) || 0;
    const s = hmsMatch[3] ? (parseInt(hmsMatch[3], 10) || 0) : 0;
    return (h * 3600 + m * 60 + s) * 1000;
  }

  const num = Number(str);
  if (!isNaN(num)) return Math.round(num * 3600 * 1000);

  return 0;
}

function htParseLeadTimeMs_(val, type) {
  if (val === null || val === undefined || val === '') return 0;

  const isDay = (type === HELP_TICKET_CONFIG.LEAD_TIME_TYPE_DAY);

  if (isDay) {
    if (val instanceof Date) {
      const frac = val.getHours() / 24 + val.getMinutes() / 1440 + val.getSeconds() / 86400;
      return Math.round(frac * 86400 * 1000);
    }
    const strD = String(val).trim();
    if (strD === '') return 0;
    const hmsD = strD.match(/^(\d{1,3}):(\d{2})(?::(\d{2}))?$/);
    if (hmsD) {
      const h = parseInt(hmsD[1], 10) || 0;
      const m = parseInt(hmsD[2], 10) || 0;
      const s = hmsD[3] ? (parseInt(hmsD[3], 10) || 0) : 0;
      return Math.round((h / 24 + m / 1440 + s / 86400) * 86400 * 1000);
    }
    const numDays = Number(strD);
    if (isNaN(numDays) || numDays < 0) return 0;
    return Math.round(numDays * 86400 * 1000);
  }

  if (val instanceof Date) {
    return (val.getHours() * 3600 + val.getMinutes() * 60 + val.getSeconds()) * 1000;
  }

  const str = String(val).trim();
  if (str === '') return 0;

  const hmsMatch = str.match(/^(\d{1,3}):(\d{2})(?::(\d{2}))?$/);
  if (hmsMatch) {
    const h = parseInt(hmsMatch[1], 10) || 0;
    const m = parseInt(hmsMatch[2], 10) || 0;
    const s = hmsMatch[3] ? (parseInt(hmsMatch[3], 10) || 0) : 0;
    return (h * 3600 + m * 60 + s) * 1000;
  }

  const numHours = Number(str);
  if (!isNaN(numHours) && numHours >= 0) {
    return Math.round(numHours * 3600 * 1000);
  }

  return 0;
}

function htFindTicketTimestamp_(htSheet, ticketId) {
  const lastRow = htSheet.getLastRow();
  if (lastRow < 2) return null;
  const values = htSheet.getRange(2, 1, lastRow - 1, 2).getValues();
  for (let i = 0; i < values.length; i++) {
    if (String(values[i][1]).trim() === String(ticketId).trim()) {
      const ts = values[i][0];
      if (ts instanceof Date) return ts;
      if (ts) {
        const d = new Date(ts);
        if (!isNaN(d.getTime())) return d;
      }
      return null;
    }
  }
  return null;
}

function htFindTicketAssignedTo_(htSheet, ticketId) {
  const lastRow = htSheet.getLastRow();
  if (lastRow < 2) return '';
  const values = htSheet.getRange(2, 1, lastRow - 1, 5).getValues();
  for (let i = 0; i < values.length; i++) {
    if (String(values[i][1]).trim() === String(ticketId).trim()) {
      return (values[i][4] || '').toString().trim();
    }
  }
  return '';
}

function htStepIndex_(stepMaster, stepName) {
  for (let i = 0; i < stepMaster.length; i++) {
    if (stepMaster[i].step === stepName) return i;
  }
  return -1;
}

function htComputeNextTicketId_(sheet) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return '1';
  const ids = sheet.getRange(2, 2, lastRow - 1, 1).getValues();
  let max = 0;
  for (let i = 0; i < ids.length; i++) {
    const raw = ids[i][0];
    if (raw === '' || raw === null || raw === undefined) continue;
    const n = parseInt(String(raw).trim(), 10);
    if (!isNaN(n) && n > max) max = n;
  }
  return String(max + 1);
}

function htReadStepMaster_() {
  const sheet = htOpenSheet_(HELP_TICKET_CONFIG.STEP_SHEET);
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) throw new Error('Step master sheet has no configured steps.');
  const values = sheet.getRange(2, 1, lastRow - 1, 5).getValues();
  const steps = [];
  for (let i = 0; i < values.length; i++) {
    const stepName = (values[i][0] || '').toString().trim();
    if (stepName === '') continue;
    steps.push({
      step: stepName,
      what: (values[i][1] || '').toString(),
      who: (values[i][2] || '').toString(),
      how: (values[i][3] || '').toString(),
      when: (values[i][4] || '').toString()
    });
  }
  if (steps.length === 0) throw new Error('Step master sheet has no usable step rows.');
  return steps;
}

function htReadStepRowByName_(stepName) {
  const sheet = htOpenSheet_(HELP_TICKET_CONFIG.STEP_SHEET);
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return null;
  const values = sheet.getRange(2, 1, lastRow - 1, 5).getValues();
  const target = String(stepName).trim();
  for (let i = 0; i < values.length; i++) {
    const rowStepName = (values[i][0] || '').toString().trim();
    if (rowStepName === target) {
      return {
        step: values[i][0],
        what: values[i][1],
        who:  values[i][2],
        how:  values[i][3],
        when: values[i][4]
      };
    }
  }
  return null;
}

function htAppendProcessRow_(sheet, ticketId, stepCfg, plannedDateTime, leadTimeType) {
  const targetRow = Math.max(sheet.getLastRow() + 1, 2);
  const planned = plannedDateTime instanceof Date ? plannedDateTime : new Date();
  const plannedStr = htFormatPlanned_(planned);

  const exactStep = htReadStepRowByName_(stepCfg.step) || stepCfg;

  sheet.getRange(targetRow, 1, 1, 11).setValues([[
    ticketId,
    exactStep.step,
    exactStep.what,
    exactStep.who,
    exactStep.how,
    exactStep.when,
    plannedStr,
    '',
    HELP_TICKET_CONFIG.STATUS_PENDING,
    '',
    leadTimeType || ''
  ]]);
  return targetRow;
}

function htComputeLeadTimeHours_(planned, actual) {
  const p = parseCompletionDateTime(planned);
  const a = parseCompletionDateTime(actual);
  if (!p || !a) return '';
  const diffMs = a.getTime() - p.getTime();
  if (diffMs < 0) return '00:00:00';
  const totalSec = Math.floor(diffMs / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  const pad = n => String(n).padStart(2, '0');
  return pad(h) + ':' + pad(m) + ':' + pad(s);
}

function htFindNextStep_(stepMaster, currentStepName) {
  let idx = -1;
  for (let i = 0; i < stepMaster.length; i++) {
    if (stepMaster[i].step === currentStepName) { idx = i; break; }
  }
  if (idx === -1 || idx + 1 >= stepMaster.length) return null;
  return stepMaster[idx + 1];
}

function htProcessRowExists_(sheet, ticketId, stepName) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return false;
  const values = sheet.getRange(2, 1, lastRow - 1, 2).getValues();
  for (let i = 0; i < values.length; i++) {
    if (String(values[i][0]).trim() === String(ticketId).trim() &&
        String(values[i][1]).trim() === String(stepName).trim()) {
      return true;
    }
  }
  return false;
}

function getHelpTickets(token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const isAdminOrEA = isAdminOrEA_(session.data.userRole);

    const htSheet = htOpenSheet_(HELP_TICKET_CONFIG.HELP_TICKET_SHEET);
    const prSheet = htOpenSheet_(HELP_TICKET_CONFIG.PROCESS_SHEET);

    const htLast = htSheet.getLastRow();
    if (htLast < 2) return successResponse([], 'No help tickets');

    const htValues = htSheet.getRange(2, 1, htLast - 1, 6).getValues();

    let prValues = [];
    const prLast = prSheet.getLastRow();
    if (prLast >= 2) prValues = prSheet.getRange(2, 1, prLast - 1, 11).getValues();

    const processByTicket = {};
    for (let i = 0; i < prValues.length; i++) {
      const tid = String(prValues[i][0] || '').trim();
      if (tid === '') continue;
      if (!processByTicket[tid]) processByTicket[tid] = [];
      processByTicket[tid].push(prValues[i]);
    }

    const tickets = [];
    for (let j = 0; j < htValues.length; j++) {
      const row = htValues[j];
      const ticketId = String(row[1] || '').trim();
      if (ticketId === '') continue;

      const problemAssignedTo = (row[4] || '').toString();

      const ticket = {
        rowNumber: j + 2,
        timestamp: htFormatCell_(row[0]),
        helpTicketNo: ticketId,
        raisedBy: (row[2] || '').toString(),
        issue: (row[3] || '').toString(),
        problemAssignedTo: problemAssignedTo,
        followUpBy: (row[5] || '').toString(),
        steps: []
      };

      const procs = processByTicket[ticketId] || [];
      for (let k = 0; k < procs.length; k++) {
        const v = procs[k];
        let whoVal = (v[3] || '').toString();

        if (k === 1) {
          whoVal = problemAssignedTo;
        }

        ticket.steps.push({
          step: (v[1] || '').toString(),
          what: (v[2] || '').toString(),
          who: whoVal,
          how: (v[4] || '').toString(),
          when: htFormatCell_(v[5]),
          planned: htFormatCell_(v[6]),
          actual: htFormatCell_(v[7]),
          status: (v[8] || '').toString(),
          leadTime: htFormatLeadTimeCell_(v[9]),
          leadTimeType: (v[10] || '').toString()
        });
      }

      if (isAdminOrEA) {
        tickets.push(ticket);
      } else {
        const currentUser = (session.data.userName || '').toString().trim().toLowerCase();
        let currentStep = null;
        for (let s = 0; s < ticket.steps.length; s++) {
          if (ticket.steps[s].status !== HELP_TICKET_CONFIG.STATUS_COMPLETED) {
            currentStep = ticket.steps[s];
            break;
          }
        }
        if (currentStep && currentStep.who.toString().trim().toLowerCase() === currentUser) {
          tickets.push(ticket);
        }
      }
    }

    return successResponse(tickets, 'Help tickets loaded');
  } catch (err) {
    return handleError(err, 'getHelpTickets');
  }
}

function getHelpTicketDoerOptions(token) {
  return getDoerList(token);
}

function createHelpTicket(formData, token) {
  const lock = LockService.getScriptLock();
  let locked = false;
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };
    if (!formData) return { success: false, message: 'No form data received' };

    const raisedBy = sanitize(formData.raisedBy);
    const issue = (formData.issue || '').toString();
    const assignedTo = sanitize(formData.problemAssignedTo);
    const followUpBy = sanitize(formData.followUpBy);

    if (raisedBy === '') return { success: false, message: 'Raised By is required' };
    if (issue.trim() === '') return { success: false, message: 'Issue is required' };
    if (assignedTo === '') return { success: false, message: 'Problem Assigned To is required' };
    if (followUpBy === '') return { success: false, message: 'Follow up By is required' };

    const stepMaster = htReadStepMaster_();

    lock.waitLock(HELP_TICKET_CONFIG.ID_LOCK_TIMEOUT_MS);
    locked = true;

    const htSheet = htOpenSheet_(HELP_TICKET_CONFIG.HELP_TICKET_SHEET);
    const prSheet = htOpenSheet_(HELP_TICKET_CONFIG.PROCESS_SHEET);

    const nextId = htComputeNextTicketId_(htSheet);
    const now = new Date();

    const htRow = Math.max(htSheet.getLastRow() + 1, 2);
    htSheet.getRange(htRow, 1, 1, 6).setValues([[
      now, nextId, raisedBy, issue, assignedTo, followUpBy
    ]]);

    const step1 = stepMaster[0];
    const step1Planned = new Date(now.getTime() + HELP_TICKET_CONFIG.STEP1_FIXED_MS);

    htAppendProcessRow_(prSheet, nextId, step1, step1Planned, '');

    lock.releaseLock();
    locked = false;

    return successResponse({
      helpTicketNo: nextId,
      firstStep: step1.step,
      row: htRow
    }, 'Help Ticket created successfully');
  } catch (err) {
    if (locked) { try { lock.releaseLock(); } catch (e) {} }
    return handleError(err, 'createHelpTicket');
  }
}

function saveHelpTicketStepAction(formData, token) {
  const lock = LockService.getScriptLock();
  let locked = false;
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };
    if (!formData) return { success: false, message: 'No form data received' };

    const ticketId = sanitize(formData.helpTicketNo);
    const stepName = sanitize(formData.step);
    const statusRaw = sanitize(formData.status);
    const leadTimeRaw = formData.leadTime;
    const leadTimeTypeRaw = formData.leadTimeType;
    const working = (formData.working || '').toString();

    if (ticketId === '') return { success: false, message: 'Help Ticket No. is required' };
    if (stepName === '') return { success: false, message: 'Step is required' };
    if (statusRaw !== HELP_TICKET_CONFIG.STATUS_YES &&
        statusRaw !== HELP_TICKET_CONFIG.STATUS_NO) {
      return { success: false, message: 'Status must be Yes or No' };
    }

    const stepMaster = htReadStepMaster_();
    const stepIdx = htStepIndex_(stepMaster, stepName);
    if (stepIdx === -1) {
      return { success: false, message: 'Step "' + stepName + '" is not configured in Step master' };
    }
    const isFirstStep = (stepIdx === 0);

    let leadTimeType = '';
    if (isFirstStep) {
      leadTimeType = (leadTimeTypeRaw === null || leadTimeTypeRaw === undefined)
        ? '' : String(leadTimeTypeRaw).trim();
      if (leadTimeType !== HELP_TICKET_CONFIG.LEAD_TIME_TYPE_DAY &&
          leadTimeType !== HELP_TICKET_CONFIG.LEAD_TIME_TYPE_TIME) {
        return { success: false, message: 'Lead Time Type must be Day or Time' };
      }
    }

    if (isFirstStep) {
      if (statusRaw === HELP_TICKET_CONFIG.STATUS_YES) {
        const ltMs = htParseLeadTimeMs_(leadTimeRaw, leadTimeType);
        if (!ltMs || ltMs <= 0) {
          return { success: false, message: 'Lead Time is required (positive number)' };
        }
      }
    } else {
      if (working.trim() === '') {
        return { success: false, message: 'Working is required for this step' };
      }
    }

    lock.waitLock(HELP_TICKET_CONFIG.ID_LOCK_TIMEOUT_MS);
    locked = true;

    const prSheet = htOpenSheet_(HELP_TICKET_CONFIG.PROCESS_SHEET);
    const htSheet = htOpenSheet_(HELP_TICKET_CONFIG.HELP_TICKET_SHEET);

    const lastRow = prSheet.getLastRow();
    if (lastRow < 2) {
      lock.releaseLock(); locked = false;
      return { success: false, message: 'Process sheet is empty' };
    }
    const prAll = prSheet.getRange(2, 1, lastRow - 1, 11).getValues();
    let targetRowNum = -1;
    let targetRow = null;
    for (let i = 0; i < prAll.length; i++) {
      if (String(prAll[i][0]).trim() === ticketId &&
          String(prAll[i][1]).trim() === stepName) {
        targetRowNum = i + 2;
        targetRow = prAll[i];
        break;
      }
    }
    if (targetRowNum === -1) {
      lock.releaseLock(); locked = false;
      return { success: false, message: 'Process row not found for this ticket/step' };
    }

    const isAdminOrEA = isAdminOrEA_(session.data.userRole);
    if (!isAdminOrEA) {
      const currentUser = (session.data.userName || '').toString().trim().toLowerCase();

      let effectiveWho = (targetRow[3] || '').toString().trim().toLowerCase();
      if (stepIdx === 1) {
        const assignedTo = htFindTicketAssignedTo_(htSheet, ticketId);
        if (assignedTo) effectiveWho = assignedTo.toLowerCase();
      }

      if (effectiveWho !== currentUser) {
        lock.releaseLock(); locked = false;
        return { success: false, message: 'You are not authorized to act on this step' };
      }
    }

    const currentStatus = String(targetRow[8] || '').trim();
    if (currentStatus === HELP_TICKET_CONFIG.STATUS_COMPLETED) {
      lock.releaseLock(); locked = false;
      return successResponse({ alreadyCompleted: true }, 'Step already completed');
    }

    const now = new Date();
    const planned = targetRow[6];

    if (statusRaw === HELP_TICKET_CONFIG.STATUS_YES) {
      let leadTime;
      if (isFirstStep) {
        const ltMs = htParseLeadTimeMs_(leadTimeRaw, leadTimeType);
        const totalSec = Math.floor(ltMs / 1000);
        const h = Math.floor(totalSec / 3600);
        const m = Math.floor((totalSec % 3600) / 60);
        const s = totalSec % 60;
        const pad = n => String(n).padStart(2, '0');
        leadTime = pad(h) + ':' + pad(m) + ':' + pad(s);

        prSheet.getRange(targetRowNum, 8, 1, 4).setValues([[
          now, HELP_TICKET_CONFIG.STATUS_COMPLETED, leadTime, leadTimeType
        ]]);
      } else {
        leadTime = htComputeLeadTimeHours_(planned, now);
        prSheet.getRange(targetRowNum, 8, 1, 3).setValues([[
          now, HELP_TICKET_CONFIG.STATUS_COMPLETED, leadTime
        ]]);
      }

      const nextStep = htFindNextStep_(stepMaster, stepName);
      let nextAdded = false;
      if (nextStep && !htProcessRowExists_(prSheet, ticketId, nextStep.step)) {
        let nextPlannedDate;
        if (stepIdx === 0) {
          const ticketTs = htFindTicketTimestamp_(htSheet, ticketId);
          const baseTs = ticketTs ? ticketTs : now;
          const ltMs = htParseLeadTimeMs_(leadTimeRaw, leadTimeType);
          nextPlannedDate = new Date(baseTs.getTime() + ltMs);
        } else if (stepIdx === 1) {
          nextPlannedDate = new Date(now.getTime() + HELP_TICKET_CONFIG.STEP3PLUS_FIXED_MS);
        } else {
          nextPlannedDate = new Date(now.getTime() + HELP_TICKET_CONFIG.STEP3PLUS_FIXED_MS);
        }

        htAppendProcessRow_(prSheet, ticketId, nextStep, nextPlannedDate, '');
        nextAdded = true;
      }

      lock.releaseLock(); locked = false;
      return successResponse({
        nextStepAdded: nextAdded,
        nextStep: nextStep ? nextStep.step : null
      }, 'Step completed successfully');
    } else {
      prSheet.getRange(targetRowNum, 8, 1, 3).setValues([[
        '', HELP_TICKET_CONFIG.STATUS_NOT_COMPLETED, ''
      ]]);
      lock.releaseLock(); locked = false;
      return successResponse({ advanced: false }, 'Step marked as Not Completed');
    }
  } catch (err) {
    if (locked) { try { lock.releaseLock(); } catch (e) {} }
    return handleError(err, 'saveHelpTicketStepAction');
  }
}

function getHelpTicketTasksForStats(doerFilter, range) {
  try {
    const prSheet = htOpenSheet_(HELP_TICKET_CONFIG.PROCESS_SHEET);
    const htSheet = htOpenSheet_(HELP_TICKET_CONFIG.HELP_TICKET_SHEET);

    const lastRow = prSheet.getLastRow();
    if (lastRow < 2) return [];

    const values = prSheet.getRange(2, 1, lastRow - 1, 11).getValues();

    const assignedToMap = {};
    const htLast = htSheet.getLastRow();
    if (htLast >= 2) {
      const htValues = htSheet.getRange(2, 1, htLast - 1, 5).getValues();
      htValues.forEach(r => {
        const tid = String(r[1] || '').trim();
        if (tid !== '') assignedToMap[tid] = (r[4] || '').toString().trim();
      });
    }

    const tasks = [];
    const filterLower = (doerFilter && doerFilter !== 'ALL')
      ? doerFilter.toString().trim().toLowerCase()
      : '';
    const now = new Date();

    const stepCounterByTicket = {};

    for (let i = 0; i < values.length; i++) {
      const r = values[i];
      const ticketId = (r[0] || '').toString().trim();
      if (ticketId === '') continue;

      const stepName = (r[1] || '').toString().trim();
      if (stepName === '') continue;

      if (!stepCounterByTicket[ticketId]) stepCounterByTicket[ticketId] = 0;
      const stepIdx = stepCounterByTicket[ticketId];
      stepCounterByTicket[ticketId]++;

      let who = (r[3] || '').toString().trim();
      if (stepIdx === 1) {
        const assignedTo = assignedToMap[ticketId];
        if (assignedTo) who = assignedTo;
      }
      if (who === '') continue;

      if (filterLower && who.toLowerCase() !== filterLower) continue;

      const plannedRaw = r[6];
      const actualRaw = r[7];
      const statusRaw = (r[8] || '').toString().trim();

      const plannedDate = parseCompletionDateTime(plannedRaw);
      const actualDate = parseCompletionDateTime(actualRaw);

      if (range && range.from && plannedDate) {
        const t = plannedDate.getTime();
        if (t < range.from.getTime() || t > range.to.getTime()) continue;
      }

      const isCompleted = (statusRaw === HELP_TICKET_CONFIG.STATUS_COMPLETED)
                          && actualDate !== null;

      let status;
      if (isCompleted) {
        status = 'COMPLETED';
      } else if (plannedDate && plannedDate.getTime() < now.getTime()) {
        status = 'OVERDUE';
      } else {
        status = 'PENDING';
      }

      tasks.push({
        source: 'helpTicket',
        taskId: ticketId,
        step: stepName,
        responsiblePerson: who,
        status: status,
        isCompleted: isCompleted,
        plannedDateTime: plannedDate ? plannedDate.getTime() : null,
        completionDateTime: actualDate ? actualDate.getTime() : null
      });
    }

    return tasks;
  } catch (err) {
    console.error('[getHelpTicketTasksForStats] ' + (err && err.message ? err.message : err));
    return [];
  }
}

// ============================================================
// ===== FMS MODULE (v3.14.0) ================================
// ============================================================
//  Flow Management System — Lazy step generation, step-wise
//  forms, dropdown options, conditional skipping, role-based UI
// ============================================================

const FMS_CONFIG = {
  MAPPING_SHEET_NAME: 'FMS Submodules',

  TASK_SHEET: 'TASK',
  STEP_SHEET: 'STEP',
  ASSIGNMENT_SHEET: 'STEP ASSIGNMENT',

  TASK_HEADERS:  ['Task ID', 'Created At', 'Created By', 'Submodule ID', 'Data JSON', 'Task Status'],
  STEP_HEADERS:  ['Step Instance ID', 'Task ID', 'Submodule ID', 'Step ID', 'Step', 'What', 'Who', 'How', 'When', 'When Unit', 'Step Order', 'Status', 'Planned', 'Actual', 'Record Type', 'Skip Reason', 'Skipped At', 'Skipped By Rule'],
  ASSIGN_HEADERS:['Assignment ID', 'Task ID', 'Step Instance ID', 'Step ID', 'Submodule ID', 'Assigned User', 'Step Order', 'Status', 'Planned', 'Actual', 'Created At', 'Completed At', 'Completion Data JSON'],

  RECORD_TYPE_DEF: 'DEFINITION',
  RECORD_TYPE_INSTANCE: 'INSTANCE',

  STEP_STATUS_PENDING: 'Pending',
  STEP_STATUS_ACTIVE: 'Active',
  STEP_STATUS_COMPLETED: 'Completed',
  STEP_STATUS_BLOCKED: 'Blocked',
  STEP_STATUS_SKIPPED: 'Skipped',

  TASK_STATUS_PENDING: 'Pending',
  TASK_STATUS_IN_PROGRESS: 'In Progress',
  TASK_STATUS_COMPLETED: 'Completed',

  ID_LOCK_TIMEOUT_MS: 30000
};

/* ---------- Central mapping ---------- */

function fmsGetMappingSheet_() {
  const ss = SpreadsheetApp.openById(CONFIG.DOER_LIST_SPREADSHEET_ID);
  let sheet = ss.getSheetByName(FMS_CONFIG.MAPPING_SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(FMS_CONFIG.MAPPING_SHEET_NAME);
    sheet.appendRow([
      'Submodule ID', 'Submodule Name', 'Description', 'Spreadsheet ID',
      'Status', 'Created At', 'Created By',
      'AddRecordConfig JSON', 'CompletionConfig JSON',
      'StepConfig JSON', 'CustomLogic JSON'
    ]);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function fmsReadSubmodules_() {
  const sheet = fmsGetMappingSheet_();
  const last = sheet.getLastRow();
  if (last < 2) return [];
  const values = sheet.getRange(2, 1, last - 1, 11).getValues();
  return values.map((r, i) => ({
    rowNumber: i + 2,
    submoduleId: String(r[0] || '').trim(),
    name: String(r[1] || '').trim(),
    description: String(r[2] || '').trim(),
    spreadsheetId: String(r[3] || '').trim(),
    status: String(r[4] || 'Active').trim(),
    createdAt: r[5] instanceof Date ? r[5].getTime() : (r[5] ? new Date(r[5]).getTime() : null),
    createdBy: String(r[6] || '').trim(),
    addRecordConfig: r[7] ? String(r[7]) : '',
    completionConfig: r[8] ? String(r[8]) : '',
    stepConfig: r[9] ? String(r[9]) : '',
    customLogic: r[10] ? String(r[10]) : ''
  })).filter(s => s.submoduleId !== '');
}

function fmsFindSubmodule_(submoduleId) {
  const list = fmsReadSubmodules_();
  for (let i = 0; i < list.length; i++) {
    if (list[i].submoduleId === String(submoduleId).trim()) return list[i];
  }
  return null;
}

function fmsGenerateSubmoduleId_(existing) {
  let max = 0;
  existing.forEach(s => {
    const m = s.submoduleId.match(/^fms-(\d+)$/i);
    if (m) {
      const n = parseInt(m[1], 10);
      if (n > max) max = n;
    }
  });
  return 'fms-' + String(max + 1).padStart(4, '0');
}

/* ---------- Spreadsheet bootstrap ---------- */

function fmsEnsureHeaders_(sheet, headers) {
  const lastCol = sheet.getLastColumn();
  const existing = lastCol > 0
    ? sheet.getRange(1, 1, 1, lastCol).getValues()[0].map(v => String(v).trim())
    : [];
  const needsWrite = headers.some((h, i) => existing[i] !== h);
  if (needsWrite) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
  }
}

function fmsCreateSubmoduleSpreadsheet_(submoduleName) {
  const ss = SpreadsheetApp.create('FMS — ' + submoduleName);
  const id = ss.getId();

  const defaultSheet = ss.getSheets()[0];
  defaultSheet.setName(FMS_CONFIG.TASK_SHEET);
  fmsEnsureHeaders_(defaultSheet, FMS_CONFIG.TASK_HEADERS);

  const stepSheet = ss.insertSheet(FMS_CONFIG.STEP_SHEET);
  fmsEnsureHeaders_(stepSheet, FMS_CONFIG.STEP_HEADERS);

  const assignSheet = ss.insertSheet(FMS_CONFIG.ASSIGNMENT_SHEET);
  fmsEnsureHeaders_(assignSheet, FMS_CONFIG.ASSIGN_HEADERS);

  ss.getSheets().forEach(s => {
    const n = s.getName();
    if (n !== FMS_CONFIG.TASK_SHEET &&
        n !== FMS_CONFIG.STEP_SHEET &&
        n !== FMS_CONFIG.ASSIGNMENT_SHEET &&
        ss.getSheets().length > 3) {
      try { ss.deleteSheet(s); } catch (e) {}
    }
  });

  return id;
}

function fmsOpenSubmoduleSheet_(submoduleId, sheetName) {
  const sub = fmsFindSubmodule_(submoduleId);
  if (!sub) throw new Error('Submodule not found: ' + submoduleId);
  if (!sub.spreadsheetId) throw new Error('Submodule has no spreadsheet');
  const ss = SpreadsheetApp.openById(sub.spreadsheetId);
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet) throw new Error('Sheet "' + sheetName + '" missing in submodule ' + submoduleId);
  return sheet;
}

/* ---------- Permission helper ---------- */

function fmsRequireAdmin_(session) {
  if (!isAdminRole_(session.data.userRole)) {
    return { ok: false, response: { success: false, message: 'Only Admin can perform this FMS action' } };
  }
  return { ok: true };
}

function fmsRequireAdminOrEA_(session) {
  if (!isAdminOrEA_(session.data.userRole)) {
    return { ok: false, response: { success: false, message: 'Only Admin or EA can perform this FMS action' } };
  }
  return { ok: true };
}

/* ============================================================
   PUBLIC API — SUBMODULE MANAGEMENT
   ============================================================ */

function fmsListSubmodules(token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const list = fmsReadSubmodules_();
    const isPriv = isAdminOrEA_(session.data.userRole);
    const visible = isPriv ? list : list.filter(s => s.status.toLowerCase() === 'active');

    const light = visible.map(s => ({
      submoduleId: s.submoduleId,
      name: s.name,
      description: s.description,
      status: s.status,
      createdAt: s.createdAt,
      createdBy: s.createdBy,
      hasAddRecordConfig: !!s.addRecordConfig,
      hasCompletionConfig: !!s.completionConfig,
      hasStepConfig: !!s.stepConfig,
      hasCustomLogic: !!s.customLogic
    }));
    return successResponse(light, 'Submodules loaded');
  } catch (err) {
    return handleError(err, 'fmsListSubmodules');
  }
}

function fmsGetSubmodule(submoduleId, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const sub = fmsFindSubmodule_(submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };

    if (isAdminOrEA_(session.data.userRole)) {
      return successResponse(sub, 'Submodule loaded');
    }
    return successResponse({
      submoduleId: sub.submoduleId,
      name: sub.name,
      description: sub.description,
      status: sub.status
    }, 'Submodule loaded');
  } catch (err) {
    return handleError(err, 'fmsGetSubmodule');
  }
}

function fmsCreateSubmodule(formData, token) {
  const lock = LockService.getScriptLock();
  let locked = false;
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };
    const guard = fmsRequireAdmin_(session);
    if (!guard.ok) return guard.response;

    if (!formData) return { success: false, message: 'No form data received' };

    const name = sanitize(formData.name);
    const description = sanitize(formData.description);
    const status = (formData.status === 'Inactive') ? 'Inactive' : 'Active';

    if (name === '') return { success: false, message: 'Submodule name is required' };

    lock.waitLock(FMS_CONFIG.ID_LOCK_TIMEOUT_MS);
    locked = true;

    const list = fmsReadSubmodules_();
    const nameLower = name.toLowerCase();
    for (let i = 0; i < list.length; i++) {
      if (list[i].name.toLowerCase() === nameLower) {
        lock.releaseLock(); locked = false;
        return { success: false, message: 'A submodule with this name already exists' };
      }
    }

    const submoduleId = fmsGenerateSubmoduleId_(list);
    const spreadsheetId = fmsCreateSubmoduleSpreadsheet_(name);
    const now = new Date();

    const sheet = fmsGetMappingSheet_();
    const targetRow = Math.max(sheet.getLastRow() + 1, 2);
    sheet.getRange(targetRow, 1, 1, 11).setValues([[
      submoduleId, name, description, spreadsheetId, status, now,
      sanitize(session.data.userName), '', '', '', ''
    ]]);

    lock.releaseLock(); locked = false;

    return successResponse({
      submoduleId: submoduleId,
      name: name,
      spreadsheetId: spreadsheetId,
      status: status
    }, 'Submodule created successfully');
  } catch (err) {
    if (locked) { try { lock.releaseLock(); } catch (e) {} }
    return handleError(err, 'fmsCreateSubmodule');
  }
}

function fmsUpdateSubmodule(formData, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };
    const guard = fmsRequireAdmin_(session);
    if (!guard.ok) return guard.response;

    if (!formData || !formData.submoduleId) {
      return { success: false, message: 'Submodule ID is required' };
    }
    const sub = fmsFindSubmodule_(formData.submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };

    const sheet = fmsGetMappingSheet_();
    if (formData.name !== undefined) {
      const newName = sanitize(formData.name);
      if (newName === '') return { success: false, message: 'Name cannot be empty' };
      const list = fmsReadSubmodules_();
      for (let i = 0; i < list.length; i++) {
        if (list[i].submoduleId !== sub.submoduleId &&
            list[i].name.toLowerCase() === newName.toLowerCase()) {
          return { success: false, message: 'Another submodule already uses this name' };
        }
      }
      sheet.getRange(sub.rowNumber, 2).setValue(newName);
    }
    if (formData.description !== undefined) {
      sheet.getRange(sub.rowNumber, 3).setValue(sanitize(formData.description));
    }
    if (formData.status !== undefined) {
      const st = (formData.status === 'Inactive') ? 'Inactive' : 'Active';
      sheet.getRange(sub.rowNumber, 5).setValue(st);
    }
    return successResponse({ submoduleId: sub.submoduleId }, 'Submodule updated');
  } catch (err) {
    return handleError(err, 'fmsUpdateSubmodule');
  }
}

/* ============================================================
   PUBLIC API — STEP BUILDER
   ============================================================ */

function fmsGetStepBuilder(submoduleId, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };
    const guard = fmsRequireAdminOrEA_(session);
    if (!guard.ok) return guard.response;

    const sub = fmsFindSubmodule_(submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };

    let cfg = [];
    if (sub.stepConfig) {
      try { cfg = JSON.parse(sub.stepConfig) || []; } catch (e) { cfg = []; }
    }
    return successResponse({ steps: cfg }, 'Step builder loaded');
  } catch (err) {
    return handleError(err, 'fmsGetStepBuilder');
  }
}

function fmsSaveStepBuilder(submoduleId, steps, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };
    const guard = fmsRequireAdmin_(session);
    if (!guard.ok) return guard.response;

    const sub = fmsFindSubmodule_(submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };

    if (!Array.isArray(steps)) return { success: false, message: 'Steps must be an array' };

    const cleaned = [];
    for (let i = 0; i < steps.length; i++) {
      const s = steps[i] || {};
      const stepName = sanitize(s.step);
      if (stepName === '') return { success: false, message: 'Step ' + (i + 1) + ': Step name is required' };

      const what = sanitize(s.what);
      const who = sanitize(s.who);
      const how = sanitize(s.how);
      const when = sanitize(s.when);
      const whenUnit = (s.whenUnit === 'Days' || s.whenUnit === 'Hours' || s.whenUnit === 'Minutes')
        ? s.whenUnit : 'Hours';

      if (what === '') return { success: false, message: 'Step "' + stepName + '": What is required' };
      if (who === '')  return { success: false, message: 'Step "' + stepName + '": Who is required' };
      if (how === '')  return { success: false, message: 'Step "' + stepName + '": How is required' };
      if (when === '') return { success: false, message: 'Step "' + stepName + '": When is required' };
      const whenNum = Number(when);
      if (isNaN(whenNum) || whenNum <= 0) {
        return { success: false, message: 'Step "' + stepName + '": When must be a positive number' };
      }

      cleaned.push({
        stepId: sanitize(s.stepId) || ('step-' + Utilities.getUuid().slice(0, 8)),
        step: stepName,
        what: what,
        who: who,
        how: how,
        when: whenNum,
        whenUnit: whenUnit,
        stepOrder: cleaned.length + 1,
        enabled: s.enabled !== false
      });
    }

    const sheet = fmsGetMappingSheet_();
    sheet.getRange(sub.rowNumber, 10).setValue(JSON.stringify(cleaned));

    return successResponse({ steps: cleaned }, 'Step builder saved');
  } catch (err) {
    return handleError(err, 'fmsSaveStepBuilder');
  }
}

/* ============================================================
   PUBLIC API — ADD RECORD FORM BUILDER
   ============================================================ */

function fmsGetAddRecordForm(submoduleId, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const sub = fmsFindSubmodule_(submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };

    let cfg = [];
    if (sub.addRecordConfig) {
      try { cfg = JSON.parse(sub.addRecordConfig) || []; } catch (e) { cfg = []; }
    }
    return successResponse({ fields: cfg }, 'Add Record form loaded');
  } catch (err) {
    return handleError(err, 'fmsGetAddRecordForm');
  }
}

function fmsSaveAddRecordForm(submoduleId, fields, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };
    const guard = fmsRequireAdmin_(session);
    if (!guard.ok) return guard.response;

    const sub = fmsFindSubmodule_(submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };

    if (!Array.isArray(fields)) return { success: false, message: 'Fields must be an array' };

    const validTypes = ['Text', 'Textarea', 'Number', 'Date', 'Time', 'DateTime',
                        'Dropdown', 'Checkbox', 'Email', 'URL'];
    const cleaned = [];
    const usedKeys = {};
    for (let i = 0; i < fields.length; i++) {
      const f = fields[i] || {};
      const label = sanitize(f.label);
      const key = sanitize(f.key);
      const type = String(f.type || 'Text');

      if (label === '') return { success: false, message: 'Field ' + (i + 1) + ': Label is required' };
      if (key === '') return { success: false, message: 'Field "' + label + '": Key is required' };
      if (usedKeys[key]) return { success: false, message: 'Duplicate field key: ' + key };
      usedKeys[key] = true;
      if (validTypes.indexOf(type) === -1) {
        return { success: false, message: 'Field "' + label + '": Unsupported type "' + type + '"' };
      }

      const clean = {
        key: key,
        label: label,
        type: type,
        required: !!f.required,
        placeholder: sanitize(f.placeholder),
        defaultValue: sanitize(f.defaultValue),
        helpText: sanitize(f.helpText),
        options: Array.isArray(f.options) ? f.options.map(o => sanitize(o)).filter(Boolean) : [],
        visible: f.visible !== false,
        readOnly: !!f.readOnly,
        order: cleaned.length + 1
      };
      if (type === 'Dropdown' && clean.options.length === 0) {
        return { success: false, message: 'Field "' + label + '": Dropdown requires at least one option' };
      }
      cleaned.push(clean);
    }

    const sheet = fmsGetMappingSheet_();
    sheet.getRange(sub.rowNumber, 8).setValue(JSON.stringify(cleaned));

    return successResponse({ fields: cleaned }, 'Add Record form saved');
  } catch (err) {
    return handleError(err, 'fmsSaveAddRecordForm');
  }
}

/* ============================================================
   PUBLIC API — COMPLETION FORM BUILDER (STEP-WISE)
   ============================================================ */

function fmsGetCompletionForm(submoduleId, stepId, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const sub = fmsFindSubmodule_(submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };

    let allConfigs = {};
    if (sub.completionConfig) {
      try {
        const parsed = JSON.parse(sub.completionConfig);
        if (Array.isArray(parsed)) {
          allConfigs = { '__GLOBAL__': parsed };
        } else if (parsed && typeof parsed === 'object') {
          allConfigs = parsed;
        }
      } catch (e) { allConfigs = {}; }
    }

    if (stepId) {
      const fields = allConfigs[String(stepId).trim()] || [];
      return successResponse({ fields: fields, stepId: stepId }, 'Step completion form loaded');
    }

    const globalFields = allConfigs['__GLOBAL__'] || [];
    return successResponse({ fields: globalFields }, 'Completion form loaded');
  } catch (err) {
    return handleError(err, 'fmsGetCompletionForm');
  }
}

function fmsSaveCompletionForm(submoduleId, stepId, fields, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };
    const guard = fmsRequireAdmin_(session);
    if (!guard.ok) return guard.response;

    const sub = fmsFindSubmodule_(submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };

    if (!Array.isArray(fields)) return { success: false, message: 'Fields must be an array' };

    let allConfigs = {};
    if (sub.completionConfig) {
      try {
        const parsed = JSON.parse(sub.completionConfig);
        if (Array.isArray(parsed)) {
          allConfigs = { '__GLOBAL__': parsed };
        } else if (parsed && typeof parsed === 'object') {
          allConfigs = parsed;
        }
      } catch (e) { allConfigs = {}; }
    }

    let addRecordFields = [];
    if (sub.addRecordConfig) {
      try { addRecordFields = JSON.parse(sub.addRecordConfig) || []; } catch (e) {}
    }
    const addKeys = addRecordFields.map(f => f.key);
    const contextKeys = ['__STEP__', '__WHO__', '__PLANNED__', '__TASK_ID__'];

    const validTypes = ['Text', 'Textarea', 'Number', 'Date', 'Time', 'DateTime',
                        'Dropdown', 'Checkbox', 'Email', 'URL', 'ReadOnly'];
    const cleaned = [];
    const usedKeys = {};
    for (let i = 0; i < fields.length; i++) {
      const f = fields[i] || {};
      const label = sanitize(f.label);
      const key = sanitize(f.key);
      const type = String(f.type || 'Text');
      if (label === '') return { success: false, message: 'Field ' + (i + 1) + ': Label is required' };
      if (key === '') return { success: false, message: 'Field "' + label + '": Key is required' };
      if (usedKeys[key]) return { success: false, message: 'Duplicate field key: ' + key };
      usedKeys[key] = true;
      if (validTypes.indexOf(type) === -1) {
        return { success: false, message: 'Field "' + label + '": Unsupported type "' + type + '"' };
      }

      if (type === 'Dropdown') {
        const opts = Array.isArray(f.options) ? f.options : [];
        const cleanOpts = [];
        const seenVals = {};
        for (let j = 0; j < opts.length; j++) {
          const opt = opts[j];
          let optLabel, optValue;
          if (typeof opt === 'string') {
            optLabel = sanitize(opt);
            optValue = sanitize(opt);
          } else {
            optLabel = sanitize(opt.label);
            optValue = sanitize(opt.value);
          }
          if (optLabel === '' || optValue === '') {
            return { success: false, message: 'Field "' + label + '": Dropdown option ' + (j + 1) + ' must have both label and value' };
          }
          if (seenVals[optValue]) {
            return { success: false, message: 'Field "' + label + '": Duplicate dropdown option value "' + optValue + '"' };
          }
          seenVals[optValue] = true;
          cleanOpts.push({ label: optLabel, value: optValue });
        }
        if (cleanOpts.length === 0) {
          return { success: false, message: 'Field "' + label + '": Dropdown requires at least one option' };
        }
        f.options = cleanOpts;
      }

      let prefill = null;
      if (f.prefillSource) {
        const ps = String(f.prefillSource).trim();
        if (contextKeys.indexOf(ps) !== -1 || addKeys.indexOf(ps) !== -1) {
          prefill = ps;
        }
      }

      cleaned.push({
        key: key,
        label: label,
        type: type,
        required: !!f.required,
        placeholder: sanitize(f.placeholder),
        defaultValue: sanitize(f.defaultValue),
        helpText: sanitize(f.helpText),
        options: (type === 'Dropdown') ? f.options : (Array.isArray(f.options) ? f.options.map(o => sanitize(o)).filter(Boolean) : []),
        readOnly: (type === 'ReadOnly') ? true : !!f.readOnly,
        prefillSource: prefill,
        order: cleaned.length + 1
      });
    }

    const key = stepId ? String(stepId).trim() : '__GLOBAL__';
    allConfigs[key] = cleaned;

    const sheet = fmsGetMappingSheet_();
    sheet.getRange(sub.rowNumber, 9).setValue(JSON.stringify(allConfigs));

    return successResponse({ fields: cleaned, stepId: stepId || '' }, 'Step completion form saved');
  } catch (err) {
    return handleError(err, 'fmsSaveCompletionForm');
  }
}

/* ============================================================
   PUBLIC API — CUSTOM LOGIC
   ============================================================ */

function fmsGetCustomLogic(submoduleId, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };
    const guard = fmsRequireAdminOrEA_(session);
    if (!guard.ok) return guard.response;

    const sub = fmsFindSubmodule_(submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };

    let rules = [];
    if (sub.customLogic) {
      try { rules = JSON.parse(sub.customLogic) || []; } catch (e) { rules = []; }
    }
    return successResponse({ rules: rules }, 'Custom logic loaded');
  } catch (err) {
    return handleError(err, 'fmsGetCustomLogic');
  }
}

function fmsSaveCustomLogic(submoduleId, rules, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };
    const guard = fmsRequireAdmin_(session);
    if (!guard.ok) return guard.response;

    const sub = fmsFindSubmodule_(submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };

    if (!Array.isArray(rules)) return { success: false, message: 'Rules must be an array' };

    let steps = [];
    if (sub.stepConfig) { try { steps = JSON.parse(sub.stepConfig) || []; } catch (e) {} }
    let addFields = [];
    if (sub.addRecordConfig) { try { addFields = JSON.parse(sub.addRecordConfig) || []; } catch (e) {} }

    const stepIds = steps.map(s => s.stepId);
    const addKeys = addFields.map(f => f.key);
    // Requirement 3: Extended operators including is_empty / is_not_empty
    const validOps = ['equals', 'not_equals', 'contains', 'greater_than', 'less_than', 'is_empty', 'is_not_empty'];
    const validActions = ['sequential', 'skip_to_target'];

    const cleaned = [];
    for (let i = 0; i < rules.length; i++) {
      const r = rules[i] || {};
      const sourceStepId = sanitize(r.sourceStepId);
      const sourceFieldKey = sanitize(r.sourceFieldKey);
      const operator = String(r.operator || 'equals');
      const compareValue = sanitize(r.compareValue);
      const targetStepId = sanitize(r.targetStepId);
      const actionType = String(r.actionType || 'sequential');

      if (!sourceStepId || (stepIds.indexOf(sourceStepId) === -1)) {
        return { success: false, message: 'Rule ' + (i + 1) + ': Invalid source step' };
      }
      const isStepField = ['status', 'who', 'actual'].indexOf(sourceFieldKey) !== -1;
      if (!isStepField && addKeys.indexOf(sourceFieldKey) === -1) {
        return { success: false, message: 'Rule ' + (i + 1) + ': Invalid source field' };
      }
      if (validOps.indexOf(operator) === -1) {
        return { success: false, message: 'Rule ' + (i + 1) + ': Invalid operator' };
      }
      if (validActions.indexOf(actionType) === -1) {
        return { success: false, message: 'Rule ' + (i + 1) + ': Invalid action type' };
      }
      if (actionType === 'skip_to_target') {
        if (!targetStepId || stepIds.indexOf(targetStepId) === -1) {
          return { success: false, message: 'Rule ' + (i + 1) + ': Invalid target step for skip action' };
        }
        const srcStep = steps.filter(s => s.stepId === sourceStepId)[0];
        const tgtStep = steps.filter(s => s.stepId === targetStepId)[0];
        if (srcStep && tgtStep && tgtStep.stepOrder <= srcStep.stepOrder) {
          return { success: false, message: 'Rule ' + (i + 1) + ': Target step must be after source step' };
        }
      } else {
        if (!targetStepId || stepIds.indexOf(targetStepId) === -1) {
          return { success: false, message: 'Rule ' + (i + 1) + ': Invalid target step' };
        }
      }

      cleaned.push({
        ruleId: sanitize(r.ruleId) || ('rule-' + Utilities.getUuid().slice(0, 8)),
        name: sanitize(r.name) || ('Rule ' + (i + 1)),
        sourceStepId: sourceStepId,
        sourceFieldKey: sourceFieldKey,
        operator: operator,
        compareValue: compareValue,
        actionType: actionType,
        targetStepId: targetStepId,
        enabled: r.enabled !== false,
        priority: cleaned.length + 1
      });
    }

    const graph = {};
    cleaned.forEach(r => {
      if (!graph[r.sourceStepId]) graph[r.sourceStepId] = [];
      graph[r.sourceStepId].push(r.targetStepId);
    });
    if (fmsHasCycle_(graph)) {
      return { success: false, message: 'Custom logic contains a circular dependency' };
    }

    const sheet = fmsGetMappingSheet_();
    sheet.getRange(sub.rowNumber, 11).setValue(JSON.stringify(cleaned));

    return successResponse({ rules: cleaned }, 'Custom logic saved');
  } catch (err) {
    return handleError(err, 'fmsSaveCustomLogic');
  }
}

function fmsHasCycle_(graph) {
  const WHITE = 0, GRAY = 1, BLACK = 2;
  const color = {};
  function visit(node) {
    color[node] = GRAY;
    const neighbors = graph[node] || [];
    for (let i = 0; i < neighbors.length; i++) {
      const n = neighbors[i];
      if (color[n] === GRAY) return true;
      if (!color[n] && visit(n)) return true;
    }
    color[node] = BLACK;
    return false;
  }
  const keys = Object.keys(graph);
  for (let i = 0; i < keys.length; i++) {
    if (!color[keys[i]]) {
      if (visit(keys[i])) return true;
    }
  }
  return false;
}

/* ============================================================
   PUBLIC API — TASK CREATION (v3.14.0 — Lazy Step Generation)
   ============================================================
   Requirement 7: ONLY Step 1 is generated at record creation.
   Subsequent steps are generated lazily when the previous step
   completes and the applicable Custom Logic / dependency rules
   determine the next eligible step.
   ============================================================ */

function fmsCreateTask(submoduleId, data, clientToken, token) {
  const lock = LockService.getScriptLock();
  let locked = false;
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };
    const guard = fmsRequireAdminOrEA_(session);
    if (!guard.ok) return guard.response;

    const sub = fmsFindSubmodule_(submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };
    if (sub.status.toLowerCase() !== 'active') {
      return { success: false, message: 'This submodule is not active' };
    }

    let addFields = [];
    if (sub.addRecordConfig) { try { addFields = JSON.parse(sub.addRecordConfig) || []; } catch (e) {} }
    if (addFields.length === 0) {
      return { success: false, message: 'Add Record form is not configured for this submodule' };
    }

    const provided = data || {};
    for (let i = 0; i < addFields.length; i++) {
      const f = addFields[i];
      if (!f.visible) continue;
      if (f.required) {
        const v = provided[f.key];
        if (v === undefined || v === null || String(v).trim() === '') {
          return { success: false, message: 'Field "' + f.label + '" is required' };
        }
      }
    }

    lock.waitLock(FMS_CONFIG.ID_LOCK_TIMEOUT_MS);
    locked = true;

    const taskSheet = fmsOpenSubmoduleSheet_(submoduleId, FMS_CONFIG.TASK_SHEET);
    const stepSheet = fmsOpenSubmoduleSheet_(submoduleId, FMS_CONFIG.STEP_SHEET);
    const assignSheet = fmsOpenSubmoduleSheet_(submoduleId, FMS_CONFIG.ASSIGNMENT_SHEET);

    const taskId = fmsNextTaskId_(taskSheet);
    const now = new Date();

    taskSheet.appendRow([
      taskId, now, sanitize(session.data.userName), submoduleId,
      JSON.stringify(provided), FMS_CONFIG.TASK_STATUS_PENDING
    ]);

    let steps = [];
    if (sub.stepConfig) { try { steps = JSON.parse(sub.stepConfig) || []; } catch (e) {} }
    const enabled = steps.filter(s => s.enabled !== false).sort((a, b) => a.stepOrder - b.stepOrder);

    if (enabled.length === 0) {
      lock.releaseLock(); locked = false;
      return successResponse({ taskId: taskId, stepsCreated: 0 },
        'Task created (no steps configured)');
    }

    // ============================================================
    // REQUIREMENT 7: Generate ONLY Step 1 — leave Steps 2+ ungenerated.
    // ============================================================
    const firstStep = enabled[0];
    const firstPlanned = new Date(now.getTime() + fmsWhenToMs_(firstStep.when, firstStep.whenUnit));

    const stepInstanceId = 'si-' + taskId + '-001';
    const assignmentId = 'as-' + taskId + '-001';

    stepSheet.appendRow([
      stepInstanceId, taskId, submoduleId, firstStep.stepId, firstStep.step,
      firstStep.what, firstStep.who, firstStep.how, firstStep.when, firstStep.whenUnit,
      firstStep.stepOrder,
      FMS_CONFIG.STEP_STATUS_ACTIVE,
      firstPlanned, '', FMS_CONFIG.RECORD_TYPE_INSTANCE,
      '', '', ''
    ]);

    assignSheet.appendRow([
      assignmentId, taskId, stepInstanceId, firstStep.stepId, submoduleId,
      firstStep.who, firstStep.stepOrder,
      FMS_CONFIG.STEP_STATUS_ACTIVE, firstPlanned, '', now, '', ''
    ]);

    lock.releaseLock(); locked = false;

    return successResponse({
      taskId: taskId,
      stepsCreated: 1,
      firstStep: firstStep.step
    }, 'Task created — Step 1 activated');
  } catch (err) {
    if (locked) { try { lock.releaseLock(); } catch (e) {} }
    return handleError(err, 'fmsCreateTask');
  }
}

function fmsWhenToMs_(when, unit) {
  const n = Number(when);
  if (isNaN(n) || n <= 0) return 0;
  if (unit === 'Days')    return n * 86400000;
  if (unit === 'Minutes') return n * 60000;
  return n * 3600000;
}

function fmsNextTaskId_(taskSheet) {
  const last = taskSheet.getLastRow();
  if (last < 2) return 'FMS-T-0001';
  const ids = taskSheet.getRange(2, 1, last - 1, 1).getValues();
  let max = 0;
  for (let i = 0; i < ids.length; i++) {
    const m = String(ids[i][0] || '').match(/FMS-T-(\d+)/i);
    if (m) {
      const n = parseInt(m[1], 10);
      if (n > max) max = n;
    }
  }
  return 'FMS-T-' + String(max + 1).padStart(4, '0');
}

/* ============================================================
   FMS INTERNAL HELPER (v3.14.0)
   Lazily create a step instance for a task. Used by fmsCompleteStep.
   ============================================================ */

function fmsGenerateStepInstance_(stepSheet, assignSheet, taskId, submoduleId, stepDef, status, plannedDate, now) {
  // Count existing step instances for this task to build a stable seq
  const sLast = stepSheet.getLastRow();
  let existingCount = 0;
  if (sLast >= 2) {
    const sVals = stepSheet.getRange(2, 1, sLast - 1, 2).getValues();
    for (let i = 0; i < sVals.length; i++) {
      if (String(sVals[i][1]).trim() === taskId) existingCount++;
    }
  }
  const seq = String(existingCount + 1).padStart(3, '0');
  const stepInstanceId = 'si-' + taskId + '-' + seq;
  const assignmentId = 'as-' + taskId + '-' + seq;

  const planned = plannedDate instanceof Date ? plannedDate : (plannedDate || '');

  stepSheet.appendRow([
    stepInstanceId, taskId, submoduleId, stepDef.stepId, stepDef.step,
    stepDef.what, stepDef.who, stepDef.how, stepDef.when, stepDef.whenUnit,
    stepDef.stepOrder,
    status,
    planned, '', FMS_CONFIG.RECORD_TYPE_INSTANCE,
    '', '', ''
  ]);

  assignSheet.appendRow([
    assignmentId, taskId, stepInstanceId, stepDef.stepId, submoduleId,
    stepDef.who, stepDef.stepOrder, status, planned, '', now, '', ''
  ]);

  return { stepInstanceId: stepInstanceId, assignmentId: assignmentId };
}

/* ============================================================
   PUBLIC API — TASK LIST
   ============================================================ */

function fmsGetTaskList(submoduleId, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const sub = fmsFindSubmodule_(submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };

    const taskSheet = fmsOpenSubmoduleSheet_(submoduleId, FMS_CONFIG.TASK_SHEET);
    const stepSheet = fmsOpenSubmoduleSheet_(submoduleId, FMS_CONFIG.STEP_SHEET);
    const assignSheet = fmsOpenSubmoduleSheet_(submoduleId, FMS_CONFIG.ASSIGNMENT_SHEET);

    const currentUser = (session.data.userName || '').toString().trim().toLowerCase();
    const isPriv = isAdminOrEA_(session.data.userRole);

    const tLast = taskSheet.getLastRow();
    const tasksById = {};
    if (tLast >= 2) {
      const tVals = taskSheet.getRange(2, 1, tLast - 1, 6).getValues();
      tVals.forEach(r => {
        const id = String(r[0] || '').trim();
        if (!id) return;
        let dataObj = {};
        try { dataObj = JSON.parse(r[4] || '{}'); } catch (e) {}
        tasksById[id] = {
          taskId: id,
          createdAt: r[1] instanceof Date ? r[1].getTime() : (r[1] ? new Date(r[1]).getTime() : null),
          createdBy: String(r[2] || ''),
          submoduleId: String(r[3] || ''),
          data: dataObj,
          status: String(r[5] || FMS_CONFIG.TASK_STATUS_PENDING),
          steps: []
        };
      });
    }

    const sLast = stepSheet.getLastRow();
    const stepInstancesById = {};
    if (sLast >= 2) {
      const sVals = stepSheet.getRange(2, 1, sLast - 1, 18).getValues();
      sVals.forEach(r => {
        const recordType = String(r[14] || '').trim();
        if (recordType === FMS_CONFIG.RECORD_TYPE_DEF) return;
        const si = String(r[0] || '').trim();
        if (!si) return;
        const taskId = String(r[1] || '').trim();
        if (!tasksById[taskId]) return;
        const stepObj = {
          stepInstanceId: si,
          taskId: taskId,
          submoduleId: String(r[2] || ''),
          stepId: String(r[3] || ''),
          step: String(r[4] || ''),
          what: String(r[5] || ''),
          who: String(r[6] || ''),
          how: String(r[7] || ''),
          when: r[8],
          whenUnit: String(r[9] || 'Hours'),
          stepOrder: Number(r[10]) || 0,
          status: String(r[11] || ''),
          planned: r[12] instanceof Date ? r[12].getTime() : (r[12] ? new Date(r[12]).getTime() : null),
          actual: r[13] instanceof Date ? r[13].getTime() : (r[13] ? new Date(r[13]).getTime() : null),
          skipReason: String(r[15] || ''),
          skippedAt: r[16] instanceof Date ? r[16].getTime() : (r[16] ? new Date(r[16]).getTime() : null),
          skippedByRule: String(r[17] || ''),
          assignment: null
        };
        stepInstancesById[si] = stepObj;
        tasksById[taskId].steps.push(stepObj);
      });
    }

    const aLast = assignSheet.getLastRow();
    if (aLast >= 2) {
      const aVals = assignSheet.getRange(2, 1, aLast - 1, 13).getValues();
      aVals.forEach(r => {
        const si = String(r[2] || '').trim();
        if (stepInstancesById[si]) {
          stepInstancesById[si].assignment = {
            assignmentId: String(r[0] || ''),
            taskId: String(r[1] || ''),
            stepInstanceId: si,
            stepId: String(r[3] || ''),
            submoduleId: String(r[4] || ''),
            assignedUser: String(r[5] || ''),
            stepOrder: Number(r[6]) || 0,
            status: String(r[7] || ''),
            planned: r[8] instanceof Date ? r[8].getTime() : (r[8] ? new Date(r[8]).getTime() : null),
            actual: r[9] instanceof Date ? r[9].getTime() : (r[9] ? new Date(r[9]).getTime() : null),
            createdAt: r[10] instanceof Date ? r[10].getTime() : null,
            completedAt: r[11] instanceof Date ? r[11].getTime() : null
          };
        }
      });
    }

    Object.keys(tasksById).forEach(tid => {
      tasksById[tid].steps.sort((a, b) => a.stepOrder - b.stepOrder);
    });

    const rows = [];
    Object.keys(tasksById).forEach(tid => {
      const t = tasksById[tid];
      if (!isPriv) {
        const mine = t.steps.filter(s =>
          s.assignment &&
          s.assignment.assignedUser.toLowerCase() === currentUser &&
          s.status !== FMS_CONFIG.STEP_STATUS_COMPLETED &&
          s.status !== FMS_CONFIG.STEP_STATUS_SKIPPED
        );
        mine.forEach(s => rows.push(fmsBuildRow_(t, s)));
      } else {
        if (t.steps.length === 0) {
          rows.push(fmsBuildRow_(t, null));
        } else {
          t.steps.forEach(s => rows.push(fmsBuildRow_(t, s)));
        }
      }
    });

    return successResponse({ tasks: rows }, 'Task list loaded');
  } catch (err) {
    return handleError(err, 'fmsGetTaskList');
  }
}

function fmsBuildRow_(task, step) {
  const pad = n => String(n).padStart(2, '0');
  function fmt(ts) {
    if (!ts) return '';
    const d = new Date(ts);
    return pad(d.getDate()) + '-' + pad(d.getMonth() + 1) + '-' + d.getFullYear() +
           ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }
  return {
    taskId: task.taskId,
    taskCreatedAt: task.createdAt,
    taskCreatedAtDisplay: fmt(task.createdAt),
    createdBy: task.createdBy,
    taskStatus: task.status,
    data: task.data,
    stepInstanceId: step ? step.stepInstanceId : '',
    stepId: step ? step.stepId : '',
    step: step ? step.step : '',
    what: step ? step.what : '',
    who: step ? step.who : '',
    how: step ? step.how : '',
    when: step ? step.when : '',
    whenUnit: step ? step.whenUnit : '',
    stepOrder: step ? step.stepOrder : 0,
    stepStatus: step ? step.status : '',
    planned: step ? step.planned : null,
    plannedDisplay: step ? fmt(step.planned) : '',
    actual: step ? step.actual : null,
    actualDisplay: step ? fmt(step.actual) : '',
    skipReason: step ? step.skipReason : '',
    skippedAt: step ? step.skippedAt : null,
    skippedByRule: step ? step.skippedByRule : '',
    assignmentId: step && step.assignment ? step.assignment.assignmentId : '',
    assignedUser: step && step.assignment ? step.assignment.assignedUser : '',
    assignmentStatus: step && step.assignment ? step.assignment.status : ''
  };
}

/* ============================================================
   PUBLIC API — COMPLETION FORM PREFILL & SUBMISSION
   ============================================================ */

function fmsGetCompletionPrefill(submoduleId, taskId, stepInstanceId, token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const sub = fmsFindSubmodule_(submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };

    const taskSheet = fmsOpenSubmoduleSheet_(submoduleId, FMS_CONFIG.TASK_SHEET);
    const stepSheet = fmsOpenSubmoduleSheet_(submoduleId, FMS_CONFIG.STEP_SHEET);

    const tLast = taskSheet.getLastRow();
    if (tLast < 2) return { success: false, message: 'Task not found' };
    const tVals = taskSheet.getRange(2, 1, tLast - 1, 6).getValues();
    let taskRow = null;
    for (let i = 0; i < tVals.length; i++) {
      if (String(tVals[i][0]).trim() === String(taskId).trim() &&
          String(tVals[i][3]).trim() === String(submoduleId).trim()) {
        taskRow = tVals[i];
        break;
      }
    }
    if (!taskRow) return { success: false, message: 'Task not found in submodule' };

    const sLast = stepSheet.getLastRow();
    if (sLast < 2) return { success: false, message: 'Step not found' };
    const sVals = stepSheet.getRange(2, 1, sLast - 1, 18).getValues();
    let stepRow = null;
    for (let i = 0; i < sVals.length; i++) {
      if (String(sVals[i][0]).trim() === String(stepInstanceId).trim() &&
          String(sVals[i][1]).trim() === String(taskId).trim()) {
        stepRow = sVals[i];
        break;
      }
    }
    if (!stepRow) return { success: false, message: 'Step instance not found' };

    const currentUser = (session.data.userName || '').toString().trim().toLowerCase();
    const assignedUser = String(stepRow[6] || '').trim().toLowerCase();
    const isPriv = isAdminOrEA_(session.data.userRole);
    if (!isPriv && assignedUser !== currentUser) {
      return { success: false, message: 'You are not authorized to complete this step' };
    }
    if (String(stepRow[11] || '').trim() === FMS_CONFIG.STEP_STATUS_COMPLETED) {
      return { success: false, message: 'This step is already completed' };
    }
    if (String(stepRow[11] || '').trim() === FMS_CONFIG.STEP_STATUS_SKIPPED) {
      return { success: false, message: 'This step has been skipped' };
    }

    let taskData = {};
    try { taskData = JSON.parse(taskRow[4] || '{}'); } catch (e) {}

    const stepId = String(stepRow[3] || '').trim();
    let fields = [];
    if (sub.completionConfig) {
      try {
        const parsed = JSON.parse(sub.completionConfig);
        if (Array.isArray(parsed)) {
          fields = parsed;
        } else if (parsed && typeof parsed === 'object') {
          fields = parsed[stepId] || parsed['__GLOBAL__'] || [];
        }
      } catch (e) { fields = []; }
    }

    const prefill = {};
    fields.forEach(f => {
      if (!f.prefillSource) {
        prefill[f.key] = f.defaultValue || '';
        return;
      }
      if (f.prefillSource === '__STEP__')    { prefill[f.key] = String(stepRow[4] || ''); return; }
      if (f.prefillSource === '__WHO__')     { prefill[f.key] = String(stepRow[6] || ''); return; }
      if (f.prefillSource === '__PLANNED__') {
        const p = stepRow[12];
        prefill[f.key] = p ? (p instanceof Date ? p.toISOString().slice(0,16) : String(p)) : '';
        return;
      }
      if (f.prefillSource === '__TASK_ID__') { prefill[f.key] = String(taskRow[0] || ''); return; }
      prefill[f.key] = (taskData[f.prefillSource] !== undefined) ? taskData[f.prefillSource] : '';
    });

    return successResponse({
      fields: fields,
      prefill: prefill,
      step: {
        stepInstanceId: String(stepRow[0]),
        taskId: String(stepRow[1]),
        step: String(stepRow[4]),
        who: String(stepRow[6]),
        stepId: stepId
      }
    }, 'Prefill loaded');
  } catch (err) {
    return handleError(err, 'fmsGetCompletionPrefill');
  }
}

/* ============================================================
   PUBLIC API — STEP COMPLETION (v3.14.0 — lazy generation)
   ============================================================ */

function fmsCompleteStep(payload, token) {
  const lock = LockService.getScriptLock();
  let locked = false;
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    if (!payload || !payload.submoduleId || !payload.taskId || !payload.stepInstanceId) {
      return { success: false, message: 'Missing required identifiers' };
    }

    const submoduleId = String(payload.submoduleId).trim();
    const taskId = String(payload.taskId).trim();
    const stepInstanceId = String(payload.stepInstanceId).trim();
    const values = payload.values || {};

    const sub = fmsFindSubmodule_(submoduleId);
    if (!sub) return { success: false, message: 'Submodule not found' };

    lock.waitLock(FMS_CONFIG.ID_LOCK_TIMEOUT_MS);
    locked = true;

    const taskSheet = fmsOpenSubmoduleSheet_(submoduleId, FMS_CONFIG.TASK_SHEET);
    const stepSheet = fmsOpenSubmoduleSheet_(submoduleId, FMS_CONFIG.STEP_SHEET);
    const assignSheet = fmsOpenSubmoduleSheet_(submoduleId, FMS_CONFIG.ASSIGNMENT_SHEET);

    const sLast = stepSheet.getLastRow();
    if (sLast < 2) { lock.releaseLock(); locked = false; return { success: false, message: 'No steps found' }; }
    const sVals = stepSheet.getRange(2, 1, sLast - 1, 18).getValues();

    let stepRowNum = -1, stepRow = null;
    for (let i = 0; i < sVals.length; i++) {
      if (String(sVals[i][0]).trim() === stepInstanceId &&
          String(sVals[i][1]).trim() === taskId) {
        stepRowNum = i + 2;
        stepRow = sVals[i];
        break;
      }
    }
    if (stepRowNum === -1) { lock.releaseLock(); locked = false; return { success: false, message: 'Step instance not found' }; }

    if (String(stepRow[11]).trim() === FMS_CONFIG.STEP_STATUS_COMPLETED) {
      lock.releaseLock(); locked = false;
      return successResponse({ alreadyCompleted: true }, 'Step already completed');
    }
    if (String(stepRow[11]).trim() === FMS_CONFIG.STEP_STATUS_SKIPPED) {
      lock.releaseLock(); locked = false;
      return { success: false, message: 'This step has been skipped' };
    }

    const currentUser = (session.data.userName || '').toString().trim().toLowerCase();
    const assignedUser = String(stepRow[6] || '').trim().toLowerCase();
    const isPriv = isAdminOrEA_(session.data.userRole);
    if (!isPriv && assignedUser !== currentUser) {
      lock.releaseLock(); locked = false;
      return { success: false, message: 'You are not authorized to complete this step' };
    }

    const stepId = String(stepRow[3] || '').trim();
    let fields = [];
    if (sub.completionConfig) {
      try {
        const parsed = JSON.parse(sub.completionConfig);
        if (Array.isArray(parsed)) {
          fields = parsed;
        } else if (parsed && typeof parsed === 'object') {
          fields = parsed[stepId] || parsed['__GLOBAL__'] || [];
        }
      } catch (e) { fields = []; }
    }

    for (let i = 0; i < fields.length; i++) {
      const f = fields[i];
      if (!f.required) continue;
      const v = values[f.key];
      if (v === undefined || v === null || String(v).trim() === '') {
        lock.releaseLock(); locked = false;
        return { success: false, message: 'Field "' + f.label + '" is required' };
      }
    }

    for (let i = 0; i < fields.length; i++) {
      const f = fields[i];
      if (f.type !== 'Dropdown') continue;
      const v = values[f.key];
      if (v === undefined || v === null || String(v).trim() === '') continue;
      const opts = f.options || [];
      let found = false;
      for (let j = 0; j < opts.length; j++) {
        const opt = opts[j];
        const optVal = (typeof opt === 'string') ? opt : (opt.value || opt.label);
        if (String(optVal) === String(v)) { found = true; break; }
      }
      if (!found) {
        lock.releaseLock(); locked = false;
        return { success: false, message: 'Field "' + f.label + '": Invalid dropdown value submitted' };
      }
    }

    const now = new Date();

    stepSheet.getRange(stepRowNum, 12).setValue(FMS_CONFIG.STEP_STATUS_COMPLETED);
    stepSheet.getRange(stepRowNum, 14).setValue(now);

    const aLast = assignSheet.getLastRow();
    let assignRowNum = -1;
    if (aLast >= 2) {
      const aVals = assignSheet.getRange(2, 1, aLast - 1, 13).getValues();
      for (let i = 0; i < aVals.length; i++) {
        if (String(aVals[i][2]).trim() === stepInstanceId &&
            String(aVals[i][1]).trim() === taskId) {
          assignRowNum = i + 2;
          break;
        }
      }
    }
    if (assignRowNum !== -1) {
      assignSheet.getRange(assignRowNum, 8).setValue(FMS_CONFIG.STEP_STATUS_COMPLETED);
      assignSheet.getRange(assignRowNum, 10).setValue(now);
      assignSheet.getRange(assignRowNum, 12).setValue(now);
      const lastCol = assignSheet.getLastColumn();
      if (lastCol < 13) assignSheet.getRange(1, 13).setValue('Completion Data JSON');
      assignSheet.getRange(assignRowNum, 13).setValue(JSON.stringify(values));
    }

    // ============================================================
    // CUSTOM LOGIC EVALUATION (Requirement 3)
    // ============================================================
    let rules = [];
    if (sub.customLogic) { try { rules = JSON.parse(sub.customLogic) || []; } catch (e) {} }

    let allStepsDefs = [];
    if (sub.stepConfig) { try { allStepsDefs = JSON.parse(sub.stepConfig) || []; } catch (e) {} }
    const enabledDefs = allStepsDefs
      .filter(s => s.enabled !== false)
      .sort((a, b) => a.stepOrder - b.stepOrder);

    const currentOrder = Number(stepRow[10]) || 0;
    let skipRuleApplied = null;

    const enabledRules = rules.filter(r => r.enabled !== false && r.sourceStepId === stepId);
    for (let rIdx = 0; rIdx < enabledRules.length; rIdx++) {
      const rule = enabledRules[rIdx];
      const srcVal = values[rule.sourceFieldKey];
      if (srcVal === undefined || srcVal === null) continue;

      let match = false;
      const cmpVal = rule.compareValue;
      const srcStr = String(srcVal);
      const cmpStr = String(cmpVal);

      switch (rule.operator) {
        case 'equals':         match = (srcStr === cmpStr); break;
        case 'not_equals':     match = (srcStr !== cmpStr); break;
        case 'contains':       match = (srcStr.indexOf(cmpStr) !== -1); break;
        case 'greater_than':   match = (Number(srcStr) > Number(cmpStr)); break;
        case 'less_than':      match = (Number(srcStr) < Number(cmpStr)); break;
        case 'is_empty':       match = (srcStr.trim() === ''); break;
        case 'is_not_empty':   match = (srcStr.trim() !== ''); break;
      }

      if (!match) continue;

      if (rule.actionType === 'skip_to_target') {
        skipRuleApplied = rule;
        break;
      }
    }

    // ============================================================
    // DETERMINE NEXT STEP
    // ============================================================
    let nextStepDef = null;
    let skippedDefs = [];
    let targetOrder = null;

    if (skipRuleApplied) {
      for (let i = 0; i < enabledDefs.length; i++) {
        if (enabledDefs[i].stepId === skipRuleApplied.targetStepId) {
          nextStepDef = enabledDefs[i];
          targetOrder = enabledDefs[i].stepOrder;
          break;
        }
      }
      if (nextStepDef) {
        for (let i = 0; i < enabledDefs.length; i++) {
          const d = enabledDefs[i];
          if (d.stepOrder > currentOrder && d.stepOrder < targetOrder) {
            skippedDefs.push(d);
          }
        }
      }
    } else {
      for (let i = 0; i < enabledDefs.length; i++) {
        if (enabledDefs[i].stepOrder === currentOrder + 1) {
          nextStepDef = enabledDefs[i];
          break;
        }
      }
      if (!nextStepDef) {
        for (let i = 0; i < enabledDefs.length; i++) {
          if (enabledDefs[i].stepOrder > currentOrder) {
            nextStepDef = enabledDefs[i];
            break;
          }
        }
      }
    }

    // ============================================================
    // PERSIST SKIPPED STEPS (audit trail — Requirement 5.4)
    // ============================================================
    for (let i = 0; i < skippedDefs.length; i++) {
      const sk = skippedDefs[i];

      // Duplicate guard
      let alreadyExists = false;
      const sLast2 = stepSheet.getLastRow();
      if (sLast2 >= 2) {
        const curVals = stepSheet.getRange(2, 1, sLast2 - 1, 11).getValues();
        for (let k = 0; k < curVals.length; k++) {
          if (String(curVals[k][1]).trim() === taskId &&
              Number(curVals[k][10]) === sk.stepOrder) {
            alreadyExists = true;
            break;
          }
        }
      }
      if (alreadyExists) continue;

      let seqCount = 0;
      if (sLast2 >= 2) {
        const curVals2 = stepSheet.getRange(2, 1, sLast2 - 1, 2).getValues();
        for (let k = 0; k < curVals2.length; k++) {
          if (String(curVals2[k][1]).trim() === taskId) seqCount++;
        }
      }
      const seq = String(seqCount + 1).padStart(3, '0');
      const skipStepInstanceId = 'si-' + taskId + '-' + seq;
      const skipAssignmentId = 'as-' + taskId + '-' + seq;

      stepSheet.appendRow([
        skipStepInstanceId, taskId, submoduleId, sk.stepId, sk.step,
        sk.what, sk.who, sk.how, sk.when, sk.whenUnit, sk.stepOrder,
        FMS_CONFIG.STEP_STATUS_SKIPPED, '', '',
        FMS_CONFIG.RECORD_TYPE_INSTANCE,
        skipRuleApplied.name || 'Custom Logic Skip',
        now,
        skipRuleApplied.ruleId
      ]);

      assignSheet.appendRow([
        skipAssignmentId, taskId, skipStepInstanceId, sk.stepId, submoduleId,
        sk.who, sk.stepOrder,
        FMS_CONFIG.STEP_STATUS_SKIPPED, '', '', now, '', ''
      ]);
    }

    // ============================================================
    // GENERATE NEXT STEP (lazily — Requirement 7)
    // ============================================================
    let activatedStep = null;
    if (nextStepDef) {
      let exists = false;
      const sLast3 = stepSheet.getLastRow();
      if (sLast3 >= 2) {
        const curVals = stepSheet.getRange(2, 1, sLast3 - 1, 11).getValues();
        for (let k = 0; k < curVals.length; k++) {
          if (String(curVals[k][1]).trim() === taskId &&
              Number(curVals[k][10]) === nextStepDef.stepOrder) {
            exists = true;
            break;
          }
        }
      }
      if (!exists) {
        const nextPlanned = new Date(now.getTime() +
          fmsWhenToMs_(nextStepDef.when, nextStepDef.whenUnit));
        const gen = fmsGenerateStepInstance_(
          stepSheet, assignSheet, taskId, submoduleId,
          nextStepDef, FMS_CONFIG.STEP_STATUS_ACTIVE, nextPlanned, now
        );
        activatedStep = { step: nextStepDef.step, instanceId: gen.stepInstanceId };
      }
    }

    // ============================================================
    // UPDATE TASK STATUS
    // ============================================================
    const tLast = taskSheet.getLastRow();
    if (tLast >= 2) {
      const tIds = taskSheet.getRange(2, 1, tLast - 1, 1).getValues();
      let taskRowNum = -1;
      for (let i = 0; i < tIds.length; i++) {
        if (String(tIds[i][0]).trim() === taskId) { taskRowNum = i + 2; break; }
      }
      if (taskRowNum !== -1) {
        const sLast4 = stepSheet.getLastRow();
        const allInstances = [];
        if (sLast4 >= 2) {
          const all = stepSheet.getRange(2, 1, sLast4 - 1, 18).getValues();
          for (let i = 0; i < all.length; i++) {
            if (String(all[i][1]).trim() === taskId &&
                String(all[i][14] || '').trim() !== FMS_CONFIG.RECORD_TYPE_DEF) {
              allInstances.push(all[i]);
            }
          }
        }
        const enabledStepCount = enabledDefs.length;
        const completedOrSkipped = allInstances.filter(r => {
          const st = String(r[11]).trim();
          return st === FMS_CONFIG.STEP_STATUS_COMPLETED || st === FMS_CONFIG.STEP_STATUS_SKIPPED;
        }).length;

        if (completedOrSkipped >= enabledStepCount && enabledStepCount > 0) {
          taskSheet.getRange(taskRowNum, 6).setValue(FMS_CONFIG.TASK_STATUS_COMPLETED);
        } else {
          taskSheet.getRange(taskRowNum, 6).setValue(FMS_CONFIG.TASK_STATUS_IN_PROGRESS);
        }
      }
    }

    lock.releaseLock(); locked = false;

    return successResponse({
      stepInstanceId: stepInstanceId,
      nextStep: activatedStep ? activatedStep.step : null,
      nextStepInstanceId: activatedStep ? activatedStep.instanceId : null,
      skippedSteps: skippedDefs.map(s => s.step),
      skipRuleApplied: skipRuleApplied ? skipRuleApplied.ruleId : null
    }, 'Step completed successfully');
  } catch (err) {
    if (locked) { try { lock.releaseLock(); } catch (e) {} }
    return handleError(err, 'fmsCompleteStep');
  }
}

/* ============================================================
   PUBLIC API — FMS DASHBOARD
   ============================================================ */

function fmsGetDashboard(token) {
  try {
    const session = validateSession(token);
    if (!session.success) return { success: false, message: 'Not authenticated' };

    const subs = fmsReadSubmodules_();
    const isPriv = isAdminOrEA_(session.data.userRole);
    const currentUser = (session.data.userName || '').toString().trim().toLowerCase();

    let totalTasks = 0, pendingTasks = 0, inProgressTasks = 0, completedTasks = 0, overdueTasks = 0;
    let pendingAssignments = 0;
    const recentCompleted = [];
    const now = Date.now();

    const activeSubs = subs.filter(s => s.status.toLowerCase() === 'active');

    activeSubs.forEach(sub => {
      try {
        const taskSheet = fmsOpenSubmoduleSheet_(sub.submoduleId, FMS_CONFIG.TASK_SHEET);
        const stepSheet = fmsOpenSubmoduleSheet_(sub.submoduleId, FMS_CONFIG.STEP_SHEET);

        const tLast = taskSheet.getLastRow();
        const tasksById = {};
        if (tLast >= 2) {
          const tVals = taskSheet.getRange(2, 1, tLast - 1, 6).getValues();
          tVals.forEach(r => {
            const id = String(r[0] || '').trim();
            if (!id) return;
            tasksById[id] = {
              status: String(r[5] || ''),
              createdAt: r[1] instanceof Date ? r[1].getTime() : null
            };
          });
        }

        const sLast = stepSheet.getLastRow();
        const stepRows = [];
        if (sLast >= 2) {
          const sVals = stepSheet.getRange(2, 1, sLast - 1, 18).getValues();
          sVals.forEach(r => {
            if (String(r[14] || '').trim() === FMS_CONFIG.RECORD_TYPE_DEF) return;
            const taskId = String(r[1] || '').trim();
            if (!tasksById[taskId]) return;
            const who = String(r[6] || '').trim().toLowerCase();
            if (!isPriv && who !== currentUser) return;
            stepRows.push(r);
          });
        }

        const visibleTaskIds = {};
        stepRows.forEach(r => { visibleTaskIds[String(r[1]).trim()] = true; });
        const visibleTasks = isPriv ? Object.keys(tasksById) : Object.keys(visibleTaskIds);

        visibleTasks.forEach(tid => {
          const t = tasksById[tid];
          if (!t) return;
          totalTasks++;
          const st = t.status.toLowerCase();
          if (st === 'completed') completedTasks++;
          else if (st === 'in progress') inProgressTasks++;
          else pendingTasks++;
        });

        stepRows.forEach(r => {
          const status = String(r[11] || '').trim();
          const planned = r[12] instanceof Date ? r[12].getTime() : (r[12] ? new Date(r[12]).getTime() : null);
          if (status === FMS_CONFIG.STEP_STATUS_ACTIVE || status === FMS_CONFIG.STEP_STATUS_BLOCKED) {
            pendingAssignments++;
            if (planned && planned < now) overdueTasks++;
          }
          if (status === FMS_CONFIG.STEP_STATUS_COMPLETED) {
            const actual = r[13] instanceof Date ? r[13].getTime() : null;
            if (actual) {
              recentCompleted.push({
                taskId: String(r[1] || ''),
                step: String(r[4] || ''),
                who: String(r[6] || ''),
                at: actual
              });
            }
          }
        });
      } catch (e) {
        console.error('[fmsGetDashboard submodule ' + sub.submoduleId + '] ' + e.message);
      }
    });

    recentCompleted.sort((a, b) => b.at - a.at);
    const topRecent = recentCompleted.slice(0, 10).map(r => ({
      taskId: r.taskId,
      step: r.step,
      who: r.who,
      atDisplay: (function(d){
        const pad = n => String(n).padStart(2, '0');
        return pad(d.getDate()) + '-' + pad(d.getMonth() + 1) + '-' + d.getFullYear() +
               ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
      })(new Date(r.at))
    }));

    return successResponse({
      totalTasks: totalTasks,
      pendingTasks: pendingTasks,
      inProgressTasks: inProgressTasks,
      completedTasks: completedTasks,
      overdueTasks: overdueTasks,
      activeSubmodules: activeSubs.length,
      pendingAssignments: pendingAssignments,
      recentlyCompleted: topRecent
    }, 'FMS dashboard loaded');
  } catch (err) {
    return handleError(err, 'fmsGetDashboard');
  }
}

function fmsGetActiveUsers(token) {
  return getDoerList(token);
}