'use strict';
process.env.SESSION_SECRET = 'test-secret-0123456789abcdef';
process.env.TZ = 'Asia/Kolkata';
const assert = require('assert');
const { createRunner } = require('../lib/runner');
const { handleRpc } = require('../lib/rpc-handler');
const { createFake } = require('./fake-google');
const code = require('../lib/code');

const C = code({ SpreadsheetApp: {}, LockService: {}, Utilities: {}, Logger: {}, __external() {}, __auth: {} }).CONFIG;
const D = (s) => new Date(s);

const fake = createFake({
  [C.DOER_LIST_SPREADSHEET_ID]: { [C.DOER_LIST_SHEET]: [
    ['Name', 'x', 'y', 'Password', 'Status'],
    ['Admin', '', '', 'adminpw', 'Active'],
    ['Ravi', '', '', 'ravipw', 'Active'],
    ['Gone', '', '', 'gonepw', 'Inactive']
  ] },
  [C.MASTER_CHECKLIST_SPREADSHEET_ID]: { [C.MASTER_CHECKLIST_SHEET]: [
    ['Task ID', 'Responsible', 'Task', 'Time', 'Date', 'Planned', 'Freq', 'Timestamp', 'Photo', 'Remarks', 'VTs', 'VStatus'],
    ['T1', 'Ravi', 'Clean desk', D('1899-12-30T04:30:00Z'), D('2026-10-13T00:00:00+05:30'), D('2026-10-13T10:00:00+05:30'), 'D', '', '', '', '', ''],
    ['T2', 'Someone', 'Other', '', '', '', 'D', '', '', '', '', '']
  ] }
});
const runner = createRunner({ google: fake, code });
const rpc = async (fn, ...args) => (await handleRpc({ fn, args }, runner));
const ok = async (fn, ...args) => { const r = await rpc(fn, ...args); assert.strictEqual(r.status, 200, fn + ' status'); assert.ok(r.json.ok, fn + ': ' + r.json.error); return r.json.result; };

(async () => {
  let n = 0; const t = async (name, f) => { await f(); n++; console.log('  ok -', name); };

  await t('unknown / internal functions are not callable', async () => {
    for (const fn of ['openSheet', 'validateSession', 'testTaskListAccess', '__proto__', 'constructor', 'CONFIG']) {
      const r = await rpc(fn, 'x'); assert.strictEqual(r.status, 404, fn);
    }
  });
  await t('bad login rejected, inactive user rejected', async () => {
    assert.strictEqual((await ok('loginUser', 'ravi', 'nope')).success, false);
    assert.strictEqual((await ok('loginUser', 'Gone', 'gonepw')).success, false);
  });
  let ravi, admin;
  await t('login (case-insensitive user) returns signed token', async () => {
    const r = await ok('loginUser', 'ravi', 'ravipw');
    assert.ok(r.success); assert.strictEqual(r.data.userName, 'Ravi'); assert.strictEqual(r.data.userRole, 'Doer'); ravi = r.data.token;
    admin = (await ok('loginUser', 'Admin', 'adminpw')).data.token;
  });
  await t('tampered / missing token is refused', async () => {
    assert.strictEqual((await ok('getChecklistTasks', ravi + 'x')).success, false);
    assert.strictEqual((await ok('getChecklistTasks')).success, false);
  });
  await t('doer sees only own checklist tasks, admin sees all', async () => {
    const mine = await ok('getChecklistTasks', ravi); assert.deepStrictEqual(mine.data.map((x) => x.taskId), ['T1']);
    const all = await ok('getChecklistTasks', admin); assert.strictEqual(all.data.length, 2);
    assert.strictEqual(mine.data[0].plannedDateTimeDisplay, '13-10-2026 10:00:00');
  });
  await t('completeChecklistTask uploads photo once and writes row', async () => {
    const r = await ok('completeChecklistTask', { taskId: 'T1', photoData: Buffer.from('img').toString('base64'), photoName: 'a.png', photoMimeType: 'image/png', remarks: 'done' }, ravi);
    assert.ok(r.success, r.message); assert.strictEqual(fake.log.uploads.length, 1);
    assert.ok(/^T1_\d+\.png$/.test(fake.log.uploads[0].fileName));
    const row = fake.books[C.MASTER_CHECKLIST_SPREADSHEET_ID].sheets[0].rows[1];
    assert.ok(String(row[8]).includes('drive.google.com')); assert.strictEqual(row[9], 'done');
    const again = await ok('completeChecklistTask', { taskId: 'T1', photoData: 'aGk=' }, ravi);
    assert.strictEqual(again.success, false); assert.strictEqual(fake.log.uploads.length, 1);
  });
  await t('failed validation writes nothing', async () => {
    const before = fake.log.flushes.length;
    const r = await ok('completeChecklistTask', { taskId: 'NOPE', photoData: 'aGk=' }, ravi);
    assert.strictEqual(r.success, false); assert.strictEqual(fake.log.flushes.length, before);
  });
  await t('FMS: doer cannot create submodule; admin can (mapping sheet + spreadsheet created)', async () => {
    assert.strictEqual((await ok('fmsCreateSubmodule', { name: 'Orders' }, ravi)).success, false);
    const r = await ok('fmsCreateSubmodule', { name: 'Orders', description: 'd' }, admin);
    assert.ok(r.success, r.message + ' ' + r.error);
    assert.strictEqual(fake.log.created.length, 1);
    const map = fake.books[C.DOER_LIST_SPREADSHEET_ID].sheets.find((s) => s.title === 'FMS Submodules');
    assert.ok(map, 'mapping sheet created'); assert.strictEqual(map.rows[1][1], 'Orders'); assert.strictEqual(map.rows[1][3], r.data.spreadsheetId);
    const dup = await ok('fmsCreateSubmodule', { name: 'orders' }, admin); assert.strictEqual(dup.success, false);
    const list = await ok('fmsListSubmodules', admin); assert.strictEqual(list.data.length, 1);
  });
  await t('concurrent write RPCs are serialised (no lost rows)', async () => {
    const before = fake.books[C.DOER_LIST_SPREADSHEET_ID].sheets[0].rows.length;
    const rs = await Promise.all([1, 2, 3].map((i) => ok('addDoerUser', { userName: 'U' + i, password: 'pw12' + i, name: 'U' + i }, admin)));
    rs.forEach((r) => assert.ok(r.success, r.message + ' ' + r.error));
    const rows = fake.books[C.DOER_LIST_SPREADSHEET_ID].sheets[0].rows;
    assert.strictEqual(rows.length, before + 3);
  });
  console.log('\n' + n + ' tests passed');
})().catch((e) => { console.error('FAIL:', e); process.exit(1); });
