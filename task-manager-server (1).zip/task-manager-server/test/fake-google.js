'use strict';
// In-memory stand-in for lib/google.js (same interface) used by the tests.
function createFake(initial) {
  const books = {}; // id -> { tz, sheets: [{title,sheetId,rows}] }
  let nextSid = 100, nextBook = 1;
  const log = { uploads: [], created: [], flushes: [], loads: 0 };
  for (const [id, sheets] of Object.entries(initial)) {
    books[id] = { tz: 'Asia/Kolkata', sheets: Object.entries(sheets).map(([title, rows], i) => ({ title, sheetId: i + 1, rows: rows.map((r) => r.slice()) })) };
  }
  const shape = (s) => {
    let lastRow = 0, lastCol = 0;
    s.rows.forEach((r, i) => r.forEach((v, j) => { if (v !== '' && v != null) { lastRow = Math.max(lastRow, i + 1); lastCol = Math.max(lastCol, j + 1); } }));
    const cells = s.rows.slice(0, lastRow).map((r) => r.slice());
    return { cells, display: cells.map((r) => r.map((v) => (v instanceof Date ? v.toISOString() : String(v)))), lastRow, lastCol };
  };
  const meta = (b) => b.sheets.map((s, i) => ({ sheetId: s.sheetId, title: s.title, index: i }));
  const get = (id) => { if (!books[id]) throw new Error('fake: no spreadsheet ' + id); return books[id]; };
  return {
    books, log,
    async loadSheets(id, names) { log.loads++; const b = get(id); const out = { timeZone: b.tz, meta: meta(b), sheets: {} }; b.sheets.forEach((s) => { if (names.includes(s.title)) out.sheets[s.title] = shape(s); }); return out; },
    async loadMeta(id) { log.loads++; const b = get(id); return { timeZone: b.tz, meta: meta(b), sheets: {} }; },
    async flush(id, ops, sheetIds) {
      log.flushes.push({ id, ops });
      const b = get(id);
      for (const op of ops) {
        if (op.t === 'add') { const s = { title: op.sheet, sheetId: nextSid++, rows: [] }; b.sheets.push(s); sheetIds.set(op.sheet, s.sheetId); continue; }
        const s = b.sheets.find((x) => x.title === op.sheet); if (!s) throw new Error('fake: no sheet ' + op.sheet);
        if (op.t === 'del') s.rows.splice(op.row - 1, 1);
        else if (op.t === 'freeze') { if (!sheetIds.get(op.sheet)) throw new Error('fake: no sheetId for freeze'); }
        else if (op.t === 'v') op.values.forEach((r, i) => r.forEach((v, j) => { while (s.rows.length < op.row + i) s.rows.push([]); const row = s.rows[op.row + i - 1]; while (row.length < op.col + j) row.push(''); row[op.col + j - 1] = v; }));
      }
    },
    async uploadPhoto(a) { log.uploads.push(a); return 'https://drive.google.com/file/d/FAKE' + log.uploads.length + '/view'; },
    async createSubmoduleSpreadsheet({ name, sheets }) { const id = 'FMSBOOK' + nextBook++; books[id] = { tz: 'Asia/Kolkata', sheets: sheets.map((s, i) => ({ title: s.title, sheetId: i + 1, rows: [s.headers.slice()] })) }; log.created.push({ id, name }); return id; }
  };
}
module.exports = { createFake };
